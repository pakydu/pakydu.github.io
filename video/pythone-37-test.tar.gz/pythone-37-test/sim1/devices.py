# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'window.ui'
#
# Created: Tue Oct 23 15:24:03 2018
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!
import sys
import os.path
import struct
import time
import serial
import random

from PyQt4 import QtCore, QtGui


def calcCRC16(data):
    crc_table = [0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241, 0xC601, 0x06C0, 0x0780, 0xC741, 0x0500,
                 0xC5C1, 0xC481, 0x0440, 0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40, 0x0A00, 0xCAC1,
                 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841, 0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81,
                 0x1A40, 0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41, 0x1400, 0xD4C1, 0xD581, 0x1540,
                 0xD701, 0x17C0, 0x1680, 0xD641, 0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040, 0xF001,
                 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240, 0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0,
                 0x3480, 0xF441, 0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41, 0xFA01, 0x3AC0, 0x3B80,
                 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840, 0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
                 0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40, 0xE401, 0x24C0, 0x2580, 0xE541, 0x2700,
                 0xE7C1, 0xE681, 0x2640, 0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041, 0xA001, 0x60C0,
                 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240, 0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480,
                 0xA441, 0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41, 0xAA01, 0x6AC0, 0x6B80, 0xAB41,
                 0x6900, 0xA9C1, 0xA881, 0x6840, 0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41, 0xBE01,
                 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40, 0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1,
                 0xB681, 0x7640, 0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041, 0x5000, 0x90C1, 0x9181,
                 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241, 0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
                 0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40, 0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901,
                 0x59C0, 0x5880, 0x9841, 0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40, 0x4E00, 0x8EC1,
                 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41, 0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680,
                 0x8641, 0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040]

    crc_hi = 0xFF
    crc_lo = 0xFF

    for w in data:
        index = crc_lo ^ ord(w)
        crc_val = crc_table[index]
        crc_temp = crc_val / 256
        crc_val_low = crc_val - (crc_temp * 256)
        crc_lo = crc_val_low ^ crc_hi
        crc_hi = crc_temp

    crc = crc_hi * 256 + crc_lo
    return crc

def get_time_stamp():
    ct = time.time()
    local_time = time.localtime(ct)
    data_head = time.strftime("%Y-%m-%d %H:%M:%S", local_time)
    data_secs = (ct - long(ct)) * 1000
    time_stamp = "%s.%03d" % (data_head, data_secs)
    return time_stamp


"""
address = chr(0x01)
function_code = chr(0x04)
start_at_reg = chr(0x10) + chr(0x06)
num_of_reg = chr(0x00) + chr(0x02)

read_device = address + function_code + start_at_reg + num_of_reg
crc = CRC16.calc(read_device)
crc_hi = crc/256
crc_lo = crc & 0xFF
"""

class regData(object):
    def __init__(self, val, vartype, dataflag, min, max, step, timeout):
        self.val = val
        self.vartype = vartype
        self.dataflag = dataflag
        self.timeout = timeout
        self.min = min
        self.max= max
        self.step = step
        self.time = time.time()
        self.preVal = val

    def getRandomFloat(self):
        curtime = time.time()
        #print "float", curtime, self.time, self.timeout
        if curtime - self.time >= self.timeout:
            self.preVal = random.uniform(self.min, self.max)
            self.time = curtime

        #print "getRandomFloat: ", self.preVal
        return self.preVal

    def getRandomInt(self):
        curtime = time.time()
        #print "int", curtime, self.time, self.timeout
        if curtime - self.time >= self.timeout:
            self.preVal = random.randint(self.min, self.max)
            self.time = curtime

        #print "getRandomInt: ", self.preVal
        return self.preVal


    def getIncreasingFloat(self):
        curtime = time.time()
        #print "float", curtime, self.time, self.timeout
        if curtime - self.time >= self.timeout:
            self.preVal += (self.step * (int(((curtime - self.time) / self.timeout))))
            self.time = curtime

        #print "getIncreasingFloat: ", self.preVal
        return self.preVal

    def getIncreasingInt(self):
        curtime = time.time()
        #print "int", curtime, self.time, self.timeout
        if curtime - self.time >= self.timeout:
            self.preVal += (self.step * (int(((curtime - self.time) / self.timeout))))
            #self.preVal += self.step
            self.time = curtime
        #print "getIncreasingInt: ", self.preVal
        return self.preVal


    def getVal(self):
        if(self.vartype) == "random":
            if(self.dataflag) == 1: #float value
                return self.getRandomFloat()
            elif (self.dataflag) == 2: #int value
                return self.getRandomInt()
            else:
                return self.preVal
        elif (self.vartype) == "increasing":
            if (self.dataflag) == 1:  # float value
                return self.getIncreasingFloat()
            elif (self.dataflag) == 2:  # int value
                return self.getIncreasingInt()
            else:
                return self.preVal
        else:
            return self.preVal

    def setVal(self, val):
        self.preVal = val

class device(object):
    def __init__(self, address, offlineDelay, devStatus):

        print "add device", address, devStatus, offlineDelay

        self.address = address
        self.offlineDelay = offlineDelay
        self.status = devStatus

        self.data = {}

    def setAppType(self, appType):
        self.appType = appType

    def getKeyValueStrFromSection(self, section, split):
        result = 0
        strKey = ""
        strVal = ""
        split = section.find(split)
        if split != -1:
            strKey = section[0:split].strip()
            strVal = section[split + 1:].strip()
        else:
            result = -1

        return result, strKey, strVal


    def setData(self, fileName):
        deviceFD = open(fileName)
        line = deviceFD.readline()
        self.setAppType(line[8:].strip())
        lineNum = 1
        while line:
            line=deviceFD.readline()
            lineNum += 1
            if line.startswith("#") or len(line.strip()) == 0:
                continue
            else:
                result = True
                line = line[0:line.find("#")]
                vartype = ""
                dataFlag = 0
                min = 0
                max = 0
                timeout = 0
                step = 0

                print line
                if line.find(",") == -1:

                    splitResult, strKey, strVal = self.getKeyValueStrFromSection(line, ":")
                    if splitResult != -1:
                        reg = int(strKey, 16)
                        val = int(strVal, 16)
                        if self.data.has_key(reg) == False:
                            print "adding ", reg, val
                            self.data[reg]=regData(val, vartype, dataFlag,min,max,step, timeout)
                        else:
                            print "Duplicated register ", reg
                    else:
                        print "000"
                        result = False
                else:
                    sections = line.split(',')
                    valSection = sections[0]
                    varTypeSection = sections[1]
                    dataFlagSection = sections[2]

                    print valSection, "---", varTypeSection, "---", dataFlagSection, "\n"

                    valSplit, strReg, strVal = self.getKeyValueStrFromSection(valSection, ":")
                    if valSplit != -1:
                        reg = int(strReg, 16)
                        val = int(strVal, 16)

                        varTypeSplit, strTypeKey, strTypeVal = self.getKeyValueStrFromSection(varTypeSection, ":")
                        if varTypeSplit != -1:
                            if strTypeVal == "increasing":
                                minSection = sections[3]
                                stepSection = sections[4]
                                timeoutSection = sections[5]

                                dataFlagSplit, strDataKey, strDataVal = self.getKeyValueStrFromSection(dataFlagSection,":")
                                if dataFlagSplit != -1:
                                    if strDataVal == "float":
                                        dataFlag = 1
                                    elif strDataVal == "int":
                                        dataFlag = 2
                                    else:
                                        dataFlag = 0
                                        result = False

                                    minSplit, strMinKey, strMinVal = self.getKeyValueStrFromSection(minSection,":")
                                    if minSplit != -1:
                                        min = int(strMinVal)
                                        stepSplit, strStepKey, strStepVal = self.getKeyValueStrFromSection(stepSection, ":")
                                        if stepSplit != -1:
                                            step = int(strStepVal)
                                            timeoutSplit, strTimeOutKey, strTimeOutVal = self.getKeyValueStrFromSection(timeoutSection, ":")
                                            if timeoutSplit != -1:
                                                timeout = int(strTimeOutVal)
                                                if self.data.has_key(reg) == False:
                                                    print "adding ", reg, val, " varType=", strTypeVal, " dataType=", strDataVal, \
                                                        " min=", min, " step=", step, " timeout=", timeout
                                                    self.data[reg] = regData(val, strTypeVal, dataFlag, min, 0, step, timeout)
                                                else:
                                                    print "Duplicated register ", reg
                                            else:
                                                result = False
                                                print "111"
                                        else:
                                            result = False
                                            print "222"
                                    else:
                                        result = False
                                        print "333"
                                else:
                                    result = False
                                    print "444"

                            elif strTypeVal == "random":
                                minSection = sections[3]
                                maxSection = sections[4]
                                timeoutSection = sections[5]

                                dataFlagSplit, strDataKey, strDataVal = self.getKeyValueStrFromSection(dataFlagSection,":")
                                if dataFlagSplit != -1:
                                    if strDataVal == "float":
                                        dataFlag = 1
                                    elif strDataVal == "int":
                                        dataFlag = 2
                                    else:
                                        dataFlag = 0
                                        result = False

                                    minSplit, strMinKey, strMinVal = self.getKeyValueStrFromSection(minSection,":")
                                    if minSplit != -1:
                                        min = int(strMinVal)
                                        maxSplit, strMaxKey, strMaxVal = self.getKeyValueStrFromSection(maxSection, ":")
                                        if maxSplit != -1:
                                            max = int(strMaxVal)
                                            timeoutSplit, strTimeOutKey, strTimeOutVal = self.getKeyValueStrFromSection(timeoutSection, ":")
                                            if timeoutSplit != -1:
                                                timeout = int(strTimeOutVal)
                                                if self.data.has_key(reg) == False:
                                                    print "adding ", reg, val, " varType=", strTypeVal, " dataType=", strDataVal, \
                                                        " min=", min, " max=", max, " timeout=", timeout
                                                    self.data[reg] = regData(val, strTypeVal, dataFlag, min, max, 0, timeout)
                                                else:
                                                    print "Duplicated register ", reg
                                            else:
                                                result = False
                                                print "1111"
                                        else:
                                            result = False
                                            print "2222"
                                    else:
                                        result = False
                                        print "3333"
                                else:
                                    result = False
                                    print "4444"

                            else:
                                #for new data type
                                print "For now no this var type ", strTypeVal
                                result = False
                                print "555"
                                pass
                        else:
                            result = False
                            print "666"
                    else:
                        result = False
                        print "777"

            if result == False:
                break

        if result == False:
            self.data.clear()
            errMsg = "Parsing data file error, Line: " + str(lineNum)
            print errMsg

        deviceFD.close()

        return result, lineNum

class deviceService(QtCore.QObject):
    updateMessage = QtCore.pyqtSignal(str)
    def __init__(self, parent = None):
        super(deviceService, self).__init__(parent)
        self.devices = {}
        self.fd = -1

    def ValidationAddress(self, startAddr, devNum):
        for index in range(startAddr, startAddr + devNum ):
            if self.devices.has_key(index) == True:
                return False
        return True

    def addDevices(self, devNum, startAddr, msgDelay, offlineNum, fileName):
        print "add devices", devNum, startAddr, msgDelay, offlineNum, fileName
        offlineNumber = offlineNum
        devStatus = "online"
        ret = 0
        lineNum = 0
        for  index in range(startAddr, startAddr + devNum ):
            if offlineNumber > 0:
                devStatus = "offline"
                offlineNumber -=1
            else:
                devStatus = "online"

            newDevice = device( index, msgDelay, devStatus)
            ret, lineNum = newDevice.setData(fileName)
            if ret == True:
                self.devices[index] = newDevice
            else:
                self.devices.clear()
                break
        return ret, lineNum

    def removeDevices(self, devNum, startAddr):
        print "remove devices", devNum, startAddr
        for  index in xrange(startAddr, startAddr + devNum ):
            if self.devices.has_key(index):
                print "remove device ", index
                self.devices.pop(index)
            else:
                print "no key", index

    def setComFd(self, fd):
        self.fd = fd

    def setRunning(self, status):
        self.running = status

    def sendMessage(self, type, buf):
        if type == 0: #req
            bufType = "-Req: "
        elif type == 1: #rsp
            bufType = "-Rsp: "
        else:
            bufType = "-Error:"

        msg = get_time_stamp() + bufType + buf
        self.updateMessage.emit(msg)

    def runOld(self):
        while True:
            byteExpected = 60
            if self.running == True and self.fd != -1 and self.fd.isOpen():
                bRead, bReadBytes, buffer = self.readSerialPort(self.fd, byteExpected)
                request = buffer
                if bRead:
                    buf = str(self.formatBuffer(buffer))
                    if bReadBytes == 6:
                        addr, func, reg, num = struct.unpack('>BBHH', buffer[0:6])
                        #print addr, func, reg, num
                        if func == 0x01 or func == 0x03 or func == 0x05 or func == 0x06:
                            byteExpected = 2
                        elif func == 0x10:
                            byteExpected = num*2 + 3

                        bRead, bReadBytes, buffer = self.readSerialPort(self.fd, byteExpected)
                        if bRead:
                            self.sendMessage(0, buf + str(self.formatBuffer(buffer)))

                            request += buffer
                            self.handleModbusRequest(self.fd, addr, func, request)
                    else:
                        buf = "bad message: " + buf
                        print buf
                        self.sendMessage(0, buf )
                else:
                    pass
                    #self.updateMessage.emit("not received")
            else:
                self.sendMessage(0, "-COM not opened or OOS")
                time.sleep(5)




    def run(self):
        while True:
            if self.running == True and self.fd != -1 and self.fd.isOpen():
                bRead, bReadBytes, buffer = self.readSerialPort(self.fd, 60)
                request = buffer
                if bRead and bReadBytes > 5:
                    buf = str(self.formatBuffer(buffer))
                    #print buf
                    self.sendMessage(0, buf)

                    addr, func = struct.unpack('>BB', buffer[0:2])
                    index = 0
                    tmpBuf = ''
                    for byteChar in buffer:
                        index+=1
                        tmpBuf += byteChar
                        if index == (bReadBytes -2):
                            break

                    #crc = struct.unpack('<H', buffer[(bReadBytes-2):bReadBytes])
                    #crc = int(crc[0])

                    #calCRC = calcCRC16(tmpBuf)
                    if 1: #calCRC == crc:
                        if self.devices.has_key(addr):
                            self.handleModbusRequest(self.fd, addr, func, request)
                        else:
                            self.sendMessage(1, "Device not exist")
                    else:
                        print "source CRC: ", crc, "calc CRC: ", calCRC
                        self.sendMessage(1, "CRC Error")
                else:
                    pass
                    #self.updateMessage.emit("not received")
            else:
                pass
                #self.sendMessage(0, "-COM not opened or OOS")
                #time.sleep(5)


    def sendResponse(self, fd, resp):
        crc = calcCRC16(resp)
        resp = resp + struct.pack('<H', crc)
        if fd.isOpen():
            fd.write(resp)
            self.sendMessage(1, str(self.formatBuffer(resp)))
        else:
            self.sendMessage(1, " Serial port closed")
        #buf = get_time_stamp() + "-Rsp: " + str(self.formatBuffer(resp))
        #self.updateMessage.emit(buf)


    def handleModbusReadCoils(self, device, fd, addr, request):
        func, reg, num = struct.unpack('>BHH', request[1:6])
        checkReg = True
        for i in xrange(0, num ):
            if device.data.has_key(reg + i) == False:
                checkReg = False
                break

        if checkReg == False:
            resp = struct.pack('>BBB', addr, 0xFF&(func | 0x80), 0xFF&num)
        else:
            resp = struct.pack('>BBB', addr, func, num)
            for i in xrange(0, num):
                resp = resp + struct.pack('>B', 0xFF & (device.data[reg + i].getVal()))
        self.sendResponse(fd, resp)

    def handleModbusReadHodlingRegisters(self, device, fd, addr, request):
        func, reg, num = struct.unpack('>BHH', request[1:6])
        checkReg = True
        for i in xrange(0, num):
            if device.data.has_key(reg + i) == False:
                print "device", addr, "has not reg", reg+i, num
                checkReg = False
                break

        if checkReg == False:
            resp = struct.pack('>BBB', addr&0xFF, (func | 0x80)&0xFF, (num*2)&0xFF)
        else:
            resp = struct.pack('>BBB', addr&0xFF, func&0xFF, (num*2)&0xFF)
            for i in xrange(0, num):
                val = device.data[reg + i].getVal()
                val = 0xFFFF & val
                print "get",'0x%x'%(reg + i), ":", '0x%x'%val, device.data[reg + i].getVal(), val
                resp = resp + struct.pack('>H', val)

        self.sendResponse(fd, resp)

    def handleModbusWriteSingleCoil(self, device, fd, addr, request):
        func, reg, val = struct.unpack('>BHH', request[1:6])
        checkReg = True
        if device.data.has_key(reg ) == False:
            checkReg = False

        if checkReg == False:
            resp = struct.pack('>BBHH', addr, func | 0x80, reg, val)
        else:
            resp = struct.pack('>BBHH', addr, func, reg, val)
        self.sendResponse(fd, resp)

    def handleModbusWriteSingleRegister(self, device, fd, addr, request):
        func, reg, val = struct.unpack('>BHH', request[1:6])
        checkReg = True
        if device.data.has_key(reg ) == False:
            checkReg = False

        if checkReg == False:
            resp = struct.pack('>BBHH', addr, func | 0x80, reg, val)
        else:
            resp = struct.pack('>BBHH', addr, func, reg, val)
        self.sendResponse(fd, resp)

    def handleModbusWriteMultiRegisters(self, device, fd, addr, request):

        requestData = request[7:]
        func, reg, num  = struct.unpack('>BHH', request[1:6])

        checkReg = True
        for i in xrange(0, num):
            if device.data.has_key(reg + i) == False:
                checkReg = False
                break


        if checkReg == False:
            resp = struct.pack('>BBHH', addr, func | 0x80, reg, num)
        else:
            if num == 1:
                if requestData.__len__() >= 2:
                    val1 = struct.unpack('>H', requestData[0: 2])
                    device.data[reg].setVal(val1)
                #print "set reg" + '0x%x' % (reg + i), reg + i, "to", val1
            elif num == 2:
                if requestData.__len__() >= 10:
                    val1, val2 = struct.unpack('>HH', requestData[0: 4])
                    device.data[reg].setVal(val1)
                    device.data[reg + 1].setVal(val2)
                #print "set reg" + '0x%x' % (reg + i), reg + i, "to", val1, val2
            elif num == 3:
                if requestData.__len__() >= 6:
                    val1, val2, val3 = struct.unpack('>HHH', requestData[0: 6])
                    device.data[reg].setVal(val1)
                    device.data[reg + 1].setVal(val2)
                    device.data[reg + 2].setVal(val3)
                #print "set reg" + '0x%x' % (reg + i), reg + i, "to", val1, val2, val3
            elif num == 4:
                if requestData.__len__() >= 8:
                    val1, val2, val3, val4 = struct.unpack('>HHHH', requestData[0: 8])
                    device.data[reg].setVal(val1)
                    device.data[reg + 1].setVal(val2)
                    device.data[reg + 2].setVal(val3)
                    device.data[reg + 3].setVal(val4)
                #print "set reg" + '0x%x' % (reg + i), reg + i, "to", val1, val2, val3, val4
            elif num == 5:
                if requestData.__len__() >= 10:
                    val1, val2, val3, val4, val5 = struct.unpack('>HHHHH', requestData[0: 10])
                    device.data[reg].setVal(val1)
                    device.data[reg + 1].setVal(val2)
                    device.data[reg + 2].setVal(val3)
                    device.data[reg + 3].setVal(val4)
                    device.data[reg + 4].setVal(val5)
                #print "set reg" + '0x%x' % (reg + i), reg + i, "to", val1, val2, val3, val4, val5

            resp = struct.pack('>BBHH', addr, func, reg, num)
        self.sendResponse(fd, resp)


    def handleModbusRequest(self, fd, addr, func, request):
        deviceOK = True
        if self.devices.has_key(addr):
            device = self.devices[addr]
            if device.status == "online":
                if device.offlineDelay > 5:
                    time.sleep(float(device.offlineDelay)/1000.0)
                if func == 0x01:
                    self.handleModbusReadCoils(device, fd, addr, request)
                elif func == 0x05:
                    self.handleModbusWriteSingleCoil(device, fd, addr, request)
                elif func == 0x06:
                    self.handleModbusWriteSingleRegister(device, fd, addr, request)
                elif func == 0x03:
                    self.handleModbusReadHodlingRegisters(device, fd, addr, request)
                elif func == 0x10:
                    self.handleModbusWriteMultiRegisters(device, fd, addr, request)
                else:
                    #buf = get_time_stamp() +  "-Rsp: " + "Not supported function code " + str(func)
                    #self.updateMessage.emit(buf)
                    self.sendMessage(1, "Not supported function code " + str(func))
            else:
                deviceOK = False
                self.sendMessage(1, "TimeOut")
        else:
            deviceOK = False
            self.sendMessage(1, "Device not exist")

    def formatBuffer(self, buffer):
        temp = ''
        for c in buffer:
            temp += '%2.2X ' % ord(c)
        #print temp
        return temp

    def readSerialPort(self, sp, expectedBytes):
        bRet, bReadBytes, buffer = False, 0, ''
        expBytes = expectedBytes
        while True:
            if sp.isOpen():
                bytes = sp.read(1)
                if len(bytes) > 0:
                    bRet = True
                    buffer = buffer + bytes
                    expBytes -=1
                    bReadBytes +=1
                    if expBytes == 0:
                        break
                #    print 'readSerialPort:' + str(len(buffer)),   hex(ord(bytes))
                else:
                    if bReadBytes > 0:
                        bRet = True
                    break

        return bRet, bReadBytes, buffer






