# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'window.ui'
#
# Created: Tue Oct 23 15:24:03 2018
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!
import sys
import math
import time
import serial
import serial.tools.list_ports
from threading import Thread

from PyQt4 import QtCore, QtGui
from window import Ui_MainWindow
from devices import deviceService
from comSetting import Ui_Dialog_COMSetting

class COM:
    pass

class COMSetting(QtGui.QDialog, Ui_Dialog_COMSetting):
    def __init__(self):
        super(COMSetting, self).__init__()
        self.setupUi(self)

class modbusSimulator(QtGui.QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(modbusSimulator, self).__init__()
        self.setupUi(self)
        self.localOperation()

    def QString2PyString(self, qStr):
        return unicode(qStr.toUtf8(), 'utf-8', 'ignore')

    def load_dev_click(self):

        fileName = QtGui.QFileDialog.getOpenFileName(self, 'Open file', '.', "txt files (*.txt)")

        if len(fileName)>0:

            objName = self.sender().objectName()
            deviceFD = open(fileName)
            firstLine=deviceFD.readline()
            deviceFD.close()

            if objName == "pushButton_LoadDev1":
                self.deviceFileName1 = fileName
                self.AppType1.setText(firstLine[8:].lstrip().rstrip())
                self.lineEdit_DevNum1.setText("1")
                self.lineEdit_StartAddr1.setText("4")
                self.lineEdit_OfflineNum1.setText("0")
                self.lineEdit_MsgDelay1.setText("30")
            elif objName == "pushButton_LoadDev2":
                self.deviceFileName2 = fileName
                self.AppType2.setText(firstLine[8:].lstrip().rstrip())
                self.lineEdit_DevNum2.setText("1")
                self.lineEdit_StartAddr2.setText("1")
                self.lineEdit_OfflineNum2.setText("0")
                self.lineEdit_MsgDelay2.setText("50")
            elif objName == "pushButton_LoadDev3":
                self.deviceFileName3 = fileName
                self.AppType3.setText(firstLine[8:].lstrip().rstrip())
                self.lineEdit_DevNum3.setText("1")
                self.lineEdit_StartAddr3.setText("1")
                self.lineEdit_OfflineNum3.setText("0")
                self.lineEdit_MsgDelay3.setText("50")
            elif objName == "pushButton_LoadDev4":
                self.deviceFileName4 = fileName
                self.AppType4.setText(firstLine[8:].lstrip().rstrip())
                self.lineEdit_DevNum4.setText("1")
                self.lineEdit_StartAddr4.setText("1")
                self.lineEdit_OfflineNum4.setText("0")
                self.lineEdit_MsgDelay4.setText("50")
            elif objName == "pushButton_LoadDev5":
                self.deviceFileName5 = fileName
                self.AppType5.setText(firstLine[8:].lstrip().rstrip())
                self.lineEdit_DevNum5.setText("1")
                self.lineEdit_StartAddr5.setText("1")
                self.lineEdit_OfflineNum5.setText("0")
                self.lineEdit_MsgDelay5.setText("50")
            else:
                self.MessageOutput.setText("wrong")

    def add_devices(self, qsDevNum, qsStartAddr, qsMsgDelay, qsOfflineDelay, labelAppType, fileName):
        strDevNum = self.QString2PyString(qsDevNum)
        strStartAddr = self.QString2PyString(qsStartAddr)
        strMsgDelay = self.QString2PyString(qsMsgDelay)
        strOfflineNum = self.QString2PyString(qsOfflineDelay)

        if strDevNum.isdigit() and strStartAddr.isdigit() and strMsgDelay.isdigit() and strOfflineNum.isdigit():
            devNum = int(qsDevNum)
            startAdr = int(qsStartAddr)
            msgDelay = int(qsMsgDelay)
            offlineNum = int(qsOfflineDelay)

            if devNum == 0:
                labelAppType.setText("None")
            elif devNum > 100 or devNum > (247 - startAdr) or offlineNum > devNum:
                QtGui.QMessageBox.information(self, "Information", self.tr("Please input correct digital value!"))
            elif self.deviceService.ValidationAddress(startAdr, devNum) == False:
                QtGui.QMessageBox.information(self, "Information", self.tr("Input address duplicated with existed devices!"))
            else:
                ret, lineNum = self.deviceService.addDevices(devNum, startAdr, msgDelay, offlineNum, fileName)
                if ret == False:
                    errMsg = "Parsing data file error, Line: " + str(lineNum)
                    QtGui.QMessageBox.information(self, "Information", self.tr(errMsg))

        else:
            QtGui.QMessageBox.information(self, "Information", self.tr("Please input digital value!"))

    def remove_devices(self, qsDevNum, qsStartAddr):
        retVal = True
        strDevNum = self.QString2PyString(qsDevNum)
        strStartAddr = self.QString2PyString(qsStartAddr)

        if strDevNum.isdigit() and strStartAddr.isdigit():
            devNum = int(qsDevNum)
            startAdr = int(qsStartAddr)
            self.deviceService.removeDevices(devNum, startAdr)
        else:
            QtGui.QMessageBox.information(self, "Information", self.tr("Please input digital value!"))
            retVal = False

        return retVal

    def clear_dev_click(self):
        objName = self.sender().objectName()

        if objName == "pushButton_ClearDev1":
            result = self.remove_devices(self.lineEdit_DevNum1.text(), self.lineEdit_StartAddr1.text())
            if result == True:
                self.deviceFileName1 = ""
                self.AppType1.setText("None")
                self.lineEdit_DevNum1.setText("0")
                self.lineEdit_StartAddr1.setText("0")
                self.lineEdit_OfflineNum1.setText("0")
                self.lineEdit_MsgDelay1.setText("0")
        elif objName == "pushButton_ClearDev2":
            result = self.remove_devices(self.lineEdit_DevNum2.text(), self.lineEdit_StartAddr2.text())
            if result == True:
                self.deviceFileName2 = ""
                self.AppType2.setText("None")
                self.lineEdit_DevNum2.setText("0")
                self.lineEdit_StartAddr2.setText("0")
                self.lineEdit_OfflineNum2.setText("0")
                self.lineEdit_MsgDelay2.setText("0")
        elif objName == "pushButton_ClearDev3":
            result = self.remove_devices(self.lineEdit_DevNum3.text(), self.lineEdit_StartAddr3.text())
            if result == True:
                self.deviceFileName3 = ""
                self.AppType3.setText("None")
                self.lineEdit_DevNum3.setText("0")
                self.lineEdit_StartAddr3.setText("0")
                self.lineEdit_OfflineNum3.setText("0")
                self.lineEdit_MsgDelay3.setText("0")
        elif objName == "pushButton_ClearDev4":
            result = self.remove_devices(self.lineEdit_DevNum4.text(), self.lineEdit_StartAddr4.text())
            if result == True:
                self.deviceFileName4 = ""
                self.AppType4.setText("None")
                self.lineEdit_DevNum4.setText("0")
                self.lineEdit_StartAddr4.setText("0")
                self.lineEdit_OfflineNum4.setText("0")
                self.lineEdit_MsgDelay4.setText("0")
        elif objName == "pushButton_ClearDev5":
            result = self.remove_devices(self.lineEdit_DevNum5.text(), self.lineEdit_StartAddr5.text())
            if result == True:
                self.deviceFileName5 = ""
                self.AppType5.setText("None")
                self.lineEdit_DevNum5.setText("0")
                self.lineEdit_StartAddr5.setText("0")
                self.lineEdit_OfflineNum5.setText("0")
                self.lineEdit_MsgDelay5.setText("0")
        else:
            self.MessageOutput.setText("wrong")

    def add_dev_click(self):
        objName = self.sender().objectName()

        if objName == "pushButton_AddDev1":
            if len(self.deviceFileName1) == 0:
                QtGui.QMessageBox.information(self, "Information", self.tr("Please load file firstly!"))
            else:
                self.MessageOutput.setText(self.deviceFileName1)
                self.add_devices(self.lineEdit_DevNum1.text(), \
                                 self.lineEdit_StartAddr1.text(), \
                                 self.lineEdit_MsgDelay1.text(), \
                                 self.lineEdit_OfflineNum1.text(), \
                                 self.AppType1, self.deviceFileName1)

        elif objName == "pushButton_AddDev2":
            if len(self.deviceFileName2) == 0:
                QtGui.QMessageBox.information(self, "Information", self.tr("Please load file firstly!"))
            else:
                self.MessageOutput.setText(self.deviceFileName2)
                self.add_devices(self.lineEdit_DevNum2.text(), \
                                 self.lineEdit_StartAddr2.text(), \
                                 self.lineEdit_MsgDelay2.text(), \
                                 self.lineEdit_OfflineNum2.text(), \
                                 self.AppType2, self.deviceFileName2)

        elif objName == "pushButton_AddDev3":
            if len(self.deviceFileName3) == 0:
                QtGui.QMessageBox.information(self, "Information", self.tr("Please load file firstly!"))
            else:
                self.MessageOutput.setText(self.deviceFileName3)
                self.add_devices(self.lineEdit_DevNum3.text(), \
                                 self.lineEdit_StartAddr3.text(), \
                                 self.lineEdit_MsgDelay3.text(), \
                                 self.lineEdit_OfflineNum3.text(), \
                                 self.AppType3, self.deviceFileName3)

        elif objName == "pushButton_AddDev4":
            if len(self.deviceFileName4) == 0:
                QtGui.QMessageBox.information(self, "Information", self.tr("Please load file firstly!"))
            else:
                self.MessageOutput.setText(self.deviceFileName4)
                self.add_devices(self.lineEdit_DevNum4.text(), \
                                 self.lineEdit_StartAddr4.text(), \
                                 self.lineEdit_MsgDelay4.text(), \
                                 self.lineEdit_OfflineNum4.text(), \
                                 self.AppType4, self.deviceFileName4)

        elif objName == "pushButton_AddDev5":
            if len(self.deviceFileName5) == 0:
                QtGui.QMessageBox.information(self, "Information", self.tr("Please load file firstly!"))
            else:
                self.MessageOutput.setText(self.deviceFileName5)
                self.add_devices(self.lineEdit_DevNum5.text(), \
                                 self.lineEdit_StartAddr5.text(), \
                                 self.lineEdit_MsgDelay5.text(), \
                                 self.lineEdit_OfflineNum5.text(), \
                                 self.AppType5, self.deviceFileName5)

        else:
            self.MessageOutput.setText("wrong button")

    def com_set(self):
        if self.pushButton_COMSetting.text() == "Open":
            self.comset = COMSetting()

            self.com.handle = serial.Serial()
            port_list = list(serial.tools.list_ports.comports())
            NoSerial = len(port_list)
            if NoSerial > 0:
                for port in port_list:
                    self.comset.comboBox_COM.addItem(port[0])  # add to comboBox

            self.comset.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
            self.comset.show()
            result = self.comset.exec_()

            if result:

                self.com.comPort =  self.comset.comboBox_COM.currentText()
                self.com.baudRate = self.comset.comboBox_BaudRate.currentText()
                self.com.dataLen =  int(self.comset.comboBox_DataSize.currentText())
                self.com.parity = self.comset.comboBox_Parity.currentText()
                self.com.stopBit = int(self.comset.comboBox_StopBit.currentText())
                self.com.rspDelay = float(self.comset.lineEdit_RspDelay.text())

                if self.com.rspDelay <= 0:
                    rspTimeout = 0.01
                else:
                    rspTimeout = float(self.com.rspDelay/1000)
                print "response delay ", rspTimeout

                if not self.com.handle.isOpen():
                    self.com.handle = serial.Serial(self.QString2PyString(self.com.comPort), self.com.baudRate, timeout = rspTimeout)
                    if self.com.handle.isOpen():
                        self.pushButton_COMSetting.setText("Close")
                        outPut = self.com.comPort + "," + str(self.com.baudRate)
                        self.COMStatus.setText(outPut)
                        self.deviceService.setComFd(self.com.handle)
                    else:
                        outPut = "Failed open" + self.com.comPort
                        self.COMStatus.setText(outPut)
                else:
                    print "already opened"
            else:
                print "not setting COM"

            del self.comset
        elif self.pushButton_COMSetting.text() == "Close":
            if self.com.handle.isOpen():
                self.com.handle.close()
                if not self.com.handle.isOpen():
                    self.pushButton_COMSetting.setText("Open")
                    self.COMStatus.setText("COM:None")
                else:
                    outPut = "Failed close" + self.com.comPort
                    self.COMStatus.setText(outPut)

    def setButtonsDisableWhenRunning(self, status):

        self.pushButton_AddDev1.setDisabled(status)
        self.pushButton_LoadDev1.setDisabled(status)
        self.pushButton_ClearDev1.setDisabled(status)
        self.pushButton_AddDev2.setDisabled(status)
        self.pushButton_LoadDev2.setDisabled(status)
        self.pushButton_ClearDev2.setDisabled(status)
        self.pushButton_AddDev3.setDisabled(status)
        self.pushButton_LoadDev3.setDisabled(status)
        self.pushButton_ClearDev3.setDisabled(status)
        self.pushButton_AddDev4.setDisabled(status)
        self.pushButton_LoadDev4.setDisabled(status)
        self.pushButton_ClearDev4.setDisabled(status)
        self.pushButton_AddDev5.setDisabled(status)
        self.pushButton_LoadDev5.setDisabled(status)
        self.pushButton_ClearDev5.setDisabled(status)
        self.pushButton_COMSetting.setDisabled(status)

        self.lineEdit_DevNum1.setDisabled(status)
        self.lineEdit_StartAddr1.setDisabled(status)
        self.lineEdit_MsgDelay1.setDisabled(status)
        self.lineEdit_OfflineNum1.setDisabled(status)
        self.lineEdit_DevNum2.setDisabled(status)
        self.lineEdit_StartAddr2.setDisabled(status)
        self.lineEdit_MsgDelay2.setDisabled(status)
        self.lineEdit_OfflineNum2.setDisabled(status)
        self.lineEdit_DevNum3.setDisabled(status)
        self.lineEdit_StartAddr3.setDisabled(status)
        self.lineEdit_MsgDelay3.setDisabled(status)
        self.lineEdit_OfflineNum3.setDisabled(status)
        self.lineEdit_DevNum4.setDisabled(status)
        self.lineEdit_StartAddr4.setDisabled(status)
        self.lineEdit_MsgDelay4.setDisabled(status)
        self.lineEdit_OfflineNum4.setDisabled(status)
        self.lineEdit_DevNum5.setDisabled(status)
        self.lineEdit_StartAddr5.setDisabled(status)
        self.lineEdit_MsgDelay5.setDisabled(status)
        self.lineEdit_OfflineNum5.setDisabled(status)

    def run(self):
        if self.pushButton_Apply.text() == "Run":
            if self.deviceService.devices.__len__() == 0:
                QtGui.QMessageBox.information(self, "Information", self.tr("Add device firstly!"))
            else:
                self.pushButton_Apply.setText("Stop")
                self.setButtonsDisableWhenRunning(True)
                self.deviceService.setRunning(True)
                self.devThread.start()

        elif self.pushButton_Apply.text() == "Stop":
            self.devThread.terminate()
            self.deviceService.setRunning(False)
            self.setButtonsDisableWhenRunning(False)
            self.pushButton_Apply.setText("Run")
            #stop running

    def updateMessageOut(self, message):
        self.MessageOutput.append(message)

    def save(self):
        fileName = QtGui.QFileDialog.getSaveFileName(self, 'save file', 'D:/')
        if len(fileName) > 0:
            print fileName
            with open(fileName, 'w') as f:
                my_text = self.MessageOutput.toPlainText()
                f.write(my_text)
        else:
            print "no filename"


    def localOperation(self):
        QtCore.QObject.connect(self.pushButton_LoadDev1, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.load_dev_click)
        QtCore.QObject.connect(self.pushButton_LoadDev2, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.load_dev_click)
        QtCore.QObject.connect(self.pushButton_LoadDev3, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.load_dev_click)
        QtCore.QObject.connect(self.pushButton_LoadDev4, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.load_dev_click)
        QtCore.QObject.connect(self.pushButton_LoadDev5, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.load_dev_click)

        QtCore.QObject.connect(self.pushButton_AddDev1, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.add_dev_click)
        QtCore.QObject.connect(self.pushButton_AddDev2, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.add_dev_click)
        QtCore.QObject.connect(self.pushButton_AddDev3, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.add_dev_click)
        QtCore.QObject.connect(self.pushButton_AddDev4, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.add_dev_click)
        QtCore.QObject.connect(self.pushButton_AddDev5, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.add_dev_click)

        QtCore.QObject.connect(self.pushButton_ClearDev1, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.clear_dev_click)
        QtCore.QObject.connect(self.pushButton_ClearDev2, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.clear_dev_click)
        QtCore.QObject.connect(self.pushButton_ClearDev3, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.clear_dev_click)
        QtCore.QObject.connect(self.pushButton_ClearDev4, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.clear_dev_click)
        QtCore.QObject.connect(self.pushButton_ClearDev5, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.clear_dev_click)

        QtCore.QObject.connect(self.pushButton_COMSetting, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.com_set)
        QtCore.QObject.connect(self.pushButton_Apply, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.run)
        QtCore.QObject.connect(self.pushButton_SaveOutput, QtCore.SIGNAL(QtCore.QString.fromUtf8("clicked()")), self.save)

        self.deviceFileName1 = ""
        self.deviceFileName2 = ""
        self.deviceFileName3 = ""
        self.deviceFileName4 = ""
        self.deviceFileName5 = ""

        self.com = COM()
        self.com.comPort = ""
        self.com.baudRate = ""
        self.com.dataLen = 0
        self.com.parity = ""
        self.com.stopBit = 0
        self.com.rspDelay = 10.0

        self.deviceService = deviceService()
        self.deviceService.updateMessage.connect(self.updateMessageOut)

        self.devThread = QtCore.QThread()
        self.deviceService.moveToThread(self.devThread)
        self.devThread.started.connect(self.deviceService.run)
