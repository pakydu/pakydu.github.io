import sys
from modbusSimulator import modbusSimulator
from PyQt4 import QtCore, QtGui


if __name__=="__main__":

    app=QtGui.QApplication(sys.argv)
    myshow=modbusSimulator()
    myshow.show()
    sys.exit(app.exec_())