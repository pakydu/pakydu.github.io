# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'comSetting.ui'
#
# Created: Fri Feb 01 16:23:53 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_COMSetting(object):
    def setupUi(self, Dialog_COMSetting):
        Dialog_COMSetting.setObjectName(_fromUtf8("Dialog_COMSetting"))
        Dialog_COMSetting.resize(411, 307)
        font = QtGui.QFont()
        font.setPointSize(12)
        Dialog_COMSetting.setFont(font)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog_COMSetting)
        self.buttonBox.setGeometry(QtCore.QRect(30, 260, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.label = QtGui.QLabel(Dialog_COMSetting)
        self.label.setGeometry(QtCore.QRect(50, 20, 61, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(Dialog_COMSetting)
        self.label_2.setGeometry(QtCore.QRect(50, 100, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_2.setFont(font)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_3 = QtGui.QLabel(Dialog_COMSetting)
        self.label_3.setGeometry(QtCore.QRect(50, 140, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.label_4 = QtGui.QLabel(Dialog_COMSetting)
        self.label_4.setGeometry(QtCore.QRect(50, 180, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.label_5 = QtGui.QLabel(Dialog_COMSetting)
        self.label_5.setGeometry(QtCore.QRect(50, 60, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_5.setFont(font)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.comboBox_BaudRate = QtGui.QComboBox(Dialog_COMSetting)
        self.comboBox_BaudRate.setGeometry(QtCore.QRect(170, 61, 101, 31))
        self.comboBox_BaudRate.setObjectName(_fromUtf8("comboBox_BaudRate"))
        self.comboBox_BaudRate.addItem(_fromUtf8(""))
        self.comboBox_BaudRate.addItem(_fromUtf8(""))
        self.comboBox_BaudRate.addItem(_fromUtf8(""))
        self.comboBox_BaudRate.addItem(_fromUtf8(""))
        self.comboBox_DataSize = QtGui.QComboBox(Dialog_COMSetting)
        self.comboBox_DataSize.setGeometry(QtCore.QRect(170, 100, 101, 31))
        self.comboBox_DataSize.setObjectName(_fromUtf8("comboBox_DataSize"))
        self.comboBox_DataSize.addItem(_fromUtf8(""))
        self.comboBox_DataSize.addItem(_fromUtf8(""))
        self.comboBox_DataSize.addItem(_fromUtf8(""))
        self.comboBox_Parity = QtGui.QComboBox(Dialog_COMSetting)
        self.comboBox_Parity.setGeometry(QtCore.QRect(170, 140, 101, 31))
        self.comboBox_Parity.setObjectName(_fromUtf8("comboBox_Parity"))
        self.comboBox_Parity.addItem(_fromUtf8(""))
        self.comboBox_Parity.addItem(_fromUtf8(""))
        self.comboBox_Parity.addItem(_fromUtf8(""))
        self.comboBox_StopBit = QtGui.QComboBox(Dialog_COMSetting)
        self.comboBox_StopBit.setGeometry(QtCore.QRect(170, 180, 101, 31))
        self.comboBox_StopBit.setObjectName(_fromUtf8("comboBox_StopBit"))
        self.comboBox_StopBit.addItem(_fromUtf8(""))
        self.comboBox_StopBit.addItem(_fromUtf8(""))
        self.comboBox_StopBit.addItem(_fromUtf8(""))
        self.comboBox_COM = QtGui.QComboBox(Dialog_COMSetting)
        self.comboBox_COM.setGeometry(QtCore.QRect(170, 20, 101, 31))
        self.comboBox_COM.setObjectName(_fromUtf8("comboBox_COM"))
        self.lineEdit_RspDelay = QtGui.QLineEdit(Dialog_COMSetting)
        self.lineEdit_RspDelay.setGeometry(QtCore.QRect(170, 220, 61, 31))
        self.lineEdit_RspDelay.setObjectName(_fromUtf8("lineEdit_RspDelay"))
        self.label_6 = QtGui.QLabel(Dialog_COMSetting)
        self.label_6.setGeometry(QtCore.QRect(50, 220, 121, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_6.setFont(font)
        self.label_6.setObjectName(_fromUtf8("label_6"))

        self.retranslateUi(Dialog_COMSetting)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialog_COMSetting.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog_COMSetting.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog_COMSetting)

    def retranslateUi(self, Dialog_COMSetting):
        Dialog_COMSetting.setWindowTitle(_translate("Dialog_COMSetting", "COM Setting", None))
        self.label.setText(_translate("Dialog_COMSetting", "COM:", None))
        self.label_2.setText(_translate("Dialog_COMSetting", "Data Size:", None))
        self.label_3.setText(_translate("Dialog_COMSetting", "Parity:", None))
        self.label_4.setText(_translate("Dialog_COMSetting", "Stop Bit:", None))
        self.label_5.setText(_translate("Dialog_COMSetting", "Baud Rate", None))
        self.comboBox_BaudRate.setItemText(0, _translate("Dialog_COMSetting", "9600", None))
        self.comboBox_BaudRate.setItemText(1, _translate("Dialog_COMSetting", "19200", None))
        self.comboBox_BaudRate.setItemText(2, _translate("Dialog_COMSetting", "38400", None))
        self.comboBox_BaudRate.setItemText(3, _translate("Dialog_COMSetting", "115200", None))
        self.comboBox_DataSize.setItemText(0, _translate("Dialog_COMSetting", "8", None))
        self.comboBox_DataSize.setItemText(1, _translate("Dialog_COMSetting", "9", None))
        self.comboBox_DataSize.setItemText(2, _translate("Dialog_COMSetting", "10", None))
        self.comboBox_Parity.setItemText(0, _translate("Dialog_COMSetting", "None", None))
        self.comboBox_Parity.setItemText(1, _translate("Dialog_COMSetting", "Odd", None))
        self.comboBox_Parity.setItemText(2, _translate("Dialog_COMSetting", "Eve", None))
        self.comboBox_StopBit.setItemText(0, _translate("Dialog_COMSetting", "0", None))
        self.comboBox_StopBit.setItemText(1, _translate("Dialog_COMSetting", "1", None))
        self.comboBox_StopBit.setItemText(2, _translate("Dialog_COMSetting", "2", None))
        self.label_6.setText(_translate("Dialog_COMSetting", "Rsp Delay (ms):", None))
        self.lineEdit_RspDelay.setText("10")

