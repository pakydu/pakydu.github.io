import threading
import time
import struct
import serial
import configparser


headerList = [0x1f, 0x30]

def ReadPortFile( OS_type ):
    port = 0
    baudrate = 9600
    config = configparser.ConfigParser()
    config.read('portCfg.ini')
    print(config.sections())
    if OS_type in config.sections():
        #items = config.options(OS_type)
        if config.has_option(OS_type, 'portName'):
            print(config[OS_type]["portName"])
            port = config[OS_type]["portName"]

        if config.has_option(OS_type, 'rate'):
            print(config[OS_type]["rate"])
            baudrate = config[OS_type]["rate"]

    return port, baudrate


def setupSerialPort( port, baudrate ):
    # print port, baudrate, serial.PARITY_NONE, serial.EIGHTBITS, serial.STOPBITS_ONE
    return serial.Serial(port=port,
                         baudrate=baudrate,
                         parity=serial.PARITY_NONE,
                         bytesize=serial.EIGHTBITS,
                         stopbits=serial.STOPBITS_ONE,
                         timeout=0.02,
                         xonxoff=0,
                         rtscts=0)

def readSerialPort( sp ):
    bRet, buffer = False, b''
    while True:
        bytes = sp.read(1)
        if len(bytes) > 0:
            bRet = True
            #buffer.append(bytes)
            #buffer = buffer.encode('utf-8')
            buffer = buffer + bytes
            print(hex(ord(bytes)))
        else:
            break
    return bRet,  buffer

def printBuffer( buffer):
    temp = ''
    for c in buffer:
        temp += '%2.2X ' % c
    print(temp)

def handleEchoStream( sp, buffer ):       
    if len(buffer) >= 2:
        header, length = struct.unpack( '>BB', buffer[0:2] )
        	
        if header not in headerList:
        		print('--------------------not support-----------------------------')
        		return ''
        	
        # read registers
        if header == 0x1f:
            #06 02 08
            resp = struct.pack( '>B',  0x06)
            resp += struct.pack( '>B',  0x02)
            resp += struct.pack( '>B',  0x08)
            sp.write(resp)
            print ('[Resp]:')
            printBuffer(resp)

        # elif func == 0x04:
        #     if len(buffer) >= 8:
        #         if checkCrc( sp, buffer[0:8] ):
        #             if checkAddress( buffer[0] ):
        #                 handleReadInputRegisters( sp, buffer[0:8] )            
        # # write single register
        # elif func == 0x06:      
        #     if len(buffer) >= 8:
        #         if checkCrc(sp,  buffer[0:8]):
        #             if checkAddress(buffer[0]):
        #                 handleWriteRegister(sp,  buffer[0:8])    
		# # write registers
        # elif func == 0x10:
        #     if len(buffer) >= 10:
        #         bytecount = ord(buffer[6]) + 9
        #         if len(buffer) >= bytecount:
        #             if checkCrc( sp, buffer[0:bytecount] ):
        #                 if checkAddress( buffer[0] ):
        #                     handleWriteRegisters( sp, buffer[0:bytecount] )
        # elif func == 0x14:
        #     # handleReadFiles( sp, buffer[0:17] )
        #     if len(buffer) >= 12:
        #         handleReadFilesExt( sp, buffer[0:10] )
        # elif func == 0x15:
        #     # handleWriteFiles( sp, buffer[0:18] )
        #     length = ord(buffer[2]) + 5
        #     if len(buffer) == length:
        #         handleWriteFilesExt( sp, buffer[0:length] )
        #     else:
        #         print "Truncated or Overflow 0x15 Command:"
        #         printBuffer( buffer )			
        # # unknow function
        else:
            print ('Unknown function: ' + str(func) )
            print (' ')
            printBuffer( buffer, 1 )
        print ('-------------------------------------------------')

    return ''


def main():
    OS_type = input("Enter your OS type: 1 for Linux, 2 for Windows -->")
    if (int(OS_type) == 1):
        OS_type = "Linux"
    else:
        OS_type = "Windows"
    
    port, baudrate = ReadPortFile(OS_type)
    if (len(port) < 2 ):
        print("COM port config is not correct.")
    print(port)

    sp = setupSerialPort(port, baudrate)

    buffer = ''

    while True:
        bRead, buffer = readSerialPort( sp )
        if bRead:
            handleEchoStream(sp, buffer)


    sp.close()

    #rt.sendport = '**1*80*'

main()