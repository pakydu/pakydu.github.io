#!/usr/bin/python3


import random
import requests
import json
import hashlib   #md5
import getpass
import time
import sys


#define the http head data members:
Http_header = {
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
    }
print("This script will help us to enable Site Supervisor SSH, and try to get its password")


"""
Request URL:http://10.161.93.24/cgi-bin/mgw.cgi
Request Method:POST
Status Code:200 OK
Remote Address:10.161.93.24:80
Referrer Policy:no-referrer-when-downgrade
Response Headers
view source
Content-Type:application/json; charset=utf-8
Date:Wed, 29 Nov 2017 02:53:48 GMT
Server:lighttpd/1.4.35
Transfer-Encoding:chunked
Request Headers
view source
Accept:*/*
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Connection:keep-alive
Content-Length:274
Content-Type:application/x-www-form-urlencoded; charset=UTF-8
Host:10.161.93.24
Origin:http://10.161.93.24
Referer:http://10.161.93.24/
User-Agent:Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36
X-Requested-With:XMLHttpRequest
Form Data
view source
view URL encoded
m: {"jsonrpc":"2.0","method":"GetAppDescription","params":{"iid":"2154097045","sid":"10b8c2ec-022d-4cb9-b932-0b4d5aec9954"},"id":"527"}
Name
SummaryDialog_tpl.html?_=2.05B00
mgw.cgi
mgw.cgi
"""
def getAppDes(ip, sessionid):

        #step 2: create "SetPointValues" message for http request.
        base_url="http://" + ip + "/cgi-bin/mgw.cgi"
        icnt = random.randint(1000,10000)
        body_setHeat = '{"jsonrpc":"2.0","method":"GetAppDescription","params":{"sid":"' + sessionid + '","iid":"2154097045"},"id":"' + str(icnt) +'"}'
        print(body_setHeat)
        payload = {'m':body_setHeat}
        rsq = requests.post(base_url, data=payload, headers= Http_header)
        print(rsq.text)
        
        
#main active:

if __name__ == "__main__":
        if (sys.version_info < (3,0)):
                print("This script needs Phthon3.x!" )
                sys.exit(0)

        SS_ip = input("\n ---> Please input your SS ip: ")
        #Sid = getSessionID(SS_ip)
        print ("\n You can get user's sid via Web UI/Browser.")
        Sid = input("---> Please input your user's sid: ")
        cnt = 1;
        while cnt < 50:
            print("Mgw GetAppDescription cnt:", str(cnt))
            cnt = cnt + 1
            getAppDes(SS_ip, Sid)
            time.sleep(2)
        
