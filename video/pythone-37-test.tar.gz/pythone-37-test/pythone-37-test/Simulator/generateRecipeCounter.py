#! /usr/bin/python

f = open('2222.txt','w')
for i in xrange(0, 1024, 16):
    szBuffer = ('0x%.4x' % (0x80ec + (i* 7) ))
    f.write(str(szBuffer))
    f.write(': ')
    for j in xrange(0,16):
        f.write('65 52 69 63 65 70 ')
		#f.write('%.2x ', i + 1)
        szRecipeCountPostFix = ('%.04d' % (i +j + 1) )
        szStrRecipeCountPostFix = str(szRecipeCountPostFix)
        for k in xrange(0,4,2):
            #ch = str(szRecipeCountPostFix[k, k+1])
            szszRecipeCountPostFixEach = ('%.2x ' % ord(szStrRecipeCountPostFix[k+1]))
            #szszRecipeCountPostFixEach = ('%.2x ', ord(ch))			
            f.write( str(szszRecipeCountPostFixEach ))
            szszRecipeCountPostFixEach = ('%.2x ' % ord(szStrRecipeCountPostFix[k]))
            f.write( str(szszRecipeCountPostFixEach ))
        f.write('00 00 ')
        szRecipeCountBufferHigh = ('%.2x ' % ((i +j +1)>>8) )
        szRecipeCountBufferLow = ('%.2x ' % ((i+j+1)&0x00ff) )

        #f.write('%.2x' % ((i+1)>>8) )
        #f.write('%.2x' % ((i+1)&0x00ff) )
        f.write(szRecipeCountBufferHigh)
        f.write(szRecipeCountBufferLow)
    f.write('\n')
		