#!/usr/bin/python

import sys
import os.path
import struct
import time
# third part of python
import serial
import crc16
import scanf


addresses = []
registers = {}

addressFileTimeStamp = 0
registerFileTimeStamp = 0
deviceIdFileTimeStamp = 0
recipeCounterFileTimeStamp = 0
errorLogFileTimeStamp = 0

def setupSerialPort( port, baudrate ):
    # print port, baudrate, serial.PARITY_NONE, serial.EIGHTBITS, serial.STOPBITS_ONE
    return serial.Serial(port=port,
                         baudrate=baudrate,
                         parity=serial.PARITY_NONE,
                         bytesize=serial.EIGHTBITS,
                         stopbits=serial.STOPBITS_ONE,
                         timeout=0.02,
                         xonxoff=0,
                         rtscts=0)

# this will return when it sees a gap in communication which means a packet has been transferred
# either master to slave or slave to master.  Modbus has no way in the packet to know which direction
# the packet is going to the timeouts are critical.
def readSerialPort( sp ):
    bRet, buffer = False, ''
    while True:
        bytes = sp.read(1)
        if len(bytes) > 0:
            bRet = True
            buffer = buffer + bytes
        #    print 'readSerialPort:' + str(len(buffer)),   hex(ord(bytes))
        else:
            break
    return bRet,  buffer

def sendResponse( sp,  addr,  resp ):
    resp = struct.pack('>B',  addr) + resp
    crc = crc16.calcString(resp,  0xffff)
    resp = resp + struct.pack('<H',  crc)
    print 'crc: ' + str(hex(crc))
    sp.write(resp)
    print '[Resp]',
    printBuffer(resp)


def checkCrc( sp,  buffer ):
    size = len(buffer) - 2
    crc = struct.unpack('<H',  buffer[size:])[0]
    crcCalc = crc16.calcString(buffer[0:size],  0xffff)
    if crc == crcCalc:
        return True
    else:
        return False


def checkAddress( buffer ):
    global addresses
    if ord(buffer[0]) not in addresses:
        return False
    return True


def printBuffer( buffer, LogToFile = 0 ):
    temp = ''
    for c in buffer:
        temp += '%2.2X ' % ord(c)
    print temp
    
    if LogToFile == 1:
        if os.path.isfile('Exception.txt') == False:
            f = open('Exception.txt','w')
            f.close()
        f = open('Exception.txt', 'a')
        lineCount = 0
        for c in buffer:
            szErrorLog = ('%.2X' % ord(c) )
            f.write(szErrorLog)
            f.write(' ')
            lineCount = lineCount + 1
            if lineCount%32 == 0:
                f.write('\n')
                lineCount = 0
        f.write('\n---------------------------------------------------------------------------------\n')
        f.close()


def handleReadRegisters( sp,  buffer ):
    func,  reg,  num = struct.unpack( '>BHH',  buffer[1:6] )
    msg = ('Handle Read Register: %3.2d' % ord(buffer[0])) + (', 0x%4.4X' % reg) + (', %3.2d' % num)
    
    # read the restiers and add each one to the response
    resp = struct.pack( '>BB',  func,  (num * 2) )
    if registers.has_key( reg ):
        if (num * 2) == len(registers[reg]):
            for i in xrange( 0, num * 2 ):
                resp = resp + struct.pack( '>B', int(registers[reg][i], 16) )
    else:
        msg = 'Not found the register: ' + hex(reg)
        resp = struct.pack( '>BB', func | 0x80, 0x02 )

    # send the response
    print msg
    print '[Reqs]',
    printBuffer(buffer)
    sendResponse(sp,  ord(buffer[0]),  resp)
	
def handleReadInputRegisters( sp,  buffer ):
    print '[Reqs]',
    printBuffer(buffer)    
    func,  reg,  num = struct.unpack( '>BHH',  buffer[1:6] )
    msg = ('Handle Read Input Register: %3.2d' % ord(buffer[0])) + (', 0x%4.4X' % reg) + (', %3.2d' % num)
    
    # read the restiers and add each one to the response
    resp = struct.pack( '>BB',  func,  (num * 2) )
	
    # update the reg, since input regs overlap with hold regs
    inputReg = 0x8000 + reg
    if registers.has_key( inputReg ):
        if (num * 2) == len(registers[inputReg]):
            for i in xrange( 0, num * 2 ):
                resp = resp + struct.pack( '>B', int(registers[inputReg][i], 16) )
    else:
        msg = 'Not found the register: ' + hex(reg)
        resp = struct.pack( '>BB', func | 0x80, 0x02 )

    # send the response
    print msg
    print '[Reqs]',
    printBuffer(buffer)
    sendResponse(sp,  ord(buffer[0]),  resp)

def handleWriteRegister(sp,  buffer):
    #time.sleep(0.1)
    func,  reg,  value = struct.unpack('>BHH',  buffer[1:6])
    if registers.has_key( reg ):
        if 2 == len(registers[reg]):
            szValueHigh = ('%.2x ' % ( value>>8 ) )
            szValueLow  = ('%.2x ' % ( value&0x00ff) )
            registers[reg][0] = szValueHigh
            registers[reg][1] = szValueLow
            # if it is "Recipe counter ready clear" command, do the clear
            if ( reg == 0x0005 ) & ( value <> 0 ):
                # just handle low byte at present
                relatedReg = 0x8000
                nValueLowTuple = scanf.sscanf( registers[relatedReg][1], "%x" )
                nValueLow = nValueLowTuple[0]
                print nValueLow
                nValueLow = nValueLow & (~0x02)
                szValueBuffer = ('%.2X' % nValueLow )
                registers[relatedReg][1] = szValueBuffer
            elif ( reg == 0x0004 ) & ( value <> 0 ):
                # just handle low byte at present
                relatedReg = 0x8000
                nValueLowTuple = scanf.sscanf( registers[relatedReg][1], "%02x" )
                nValueLow = nValueLowTuple[0]
                nValueLow = nValueLow & (~0x01)
                szValueBuffer = ('%.2X' % nValueLow )
                registers[relatedReg][1] = szValueBuffer                
    # in this case, we will just write the response which is identical to the request
    print 'handleWriteRegister: ' + str(ord(buffer[0])) + ', ' + hex(reg) + ', ' + hex(value)
    sendResponse(sp,  ord(buffer[0]),  buffer[1:6])
    
def handleWriteRegisters(sp,  buffer):
    func,  reg,  num = struct.unpack('>BHH',  buffer[1:6])
    # in this case, we will just write the response which is identical to the request
    print ('Handle Write Register: %3.2d' % ord(buffer[0])) + (', 0x%4.4X' % reg) + (', %3.2d' % num)
    print '[Reqs]',
    printBuffer(buffer)
    sendResponse(sp,  ord(buffer[0]),  buffer[1:6])
    
def handleReadFiles(sp, buffer):
    func, byteCount = struct.unpack( '>BB', buffer[1:3] )
    msg = ('Handle Read files: %3.2d' % ord(buffer[0])) + (', %3.2d' % byteCount)
	
    resp = struct.pack( '>B', func)
    resp = resp + struct.pack( '>B', int('0C',16) )
    resp = resp + struct.pack( '>B', int('05',16) )
    resp = resp + struct.pack( '>B', int('06',16) )
    resp = resp + struct.pack( '>B', int('0D',16) )
    resp = resp + struct.pack( '>B', int('FE',16) )
    resp = resp + struct.pack( '>B', int('00',16) )
    resp = resp + struct.pack( '>B', int('20',16) )
    resp = resp + struct.pack( '>B', int('05',16) )
    resp = resp + struct.pack( '>B', int('06',16) )
    resp = resp + struct.pack( '>B', int('33',16) )
    resp = resp + struct.pack( '>B', int('CD',16) )
    resp = resp + struct.pack( '>B', int('00',16) )
    resp = resp + struct.pack( '>B', int('40',16) )
	
    print msg
    printBuffer(buffer)
    sendResponse(sp,  ord(buffer[0]),  resp)

def handleReadFilesExt(sp, buffer):
    func, byteCount, refType, fileNumber, recNumber, regCount = struct.unpack( '>BBBHHH', buffer[1:10] )
    msg = ('Handle Read files: %3.2d' % ord(buffer[0])) + (', %3.2d' % byteCount) + (', %3.2d' % recNumber)
	
    if fileNumber == 5:
        fName = 'COUNT000.csv'
    elif fileNumber == 4:
        fName = 'ERROR000.csv'
    else:
        fName = 'COUNT000.csv'
		
    if os.path.getsize(fName) <= recNumber*244:
        # build exception response with '02' code
        resp = struct.pack( '>B', func|0x80)
        resp = resp + struct.pack( '>B', 0x02 )
    else:
        fRealRead = 0
        fHandle = open(fName, 'r')
        fHandle.seek(recNumber*244)
        
        for i in range(1, regCount*2 + 1):
            char = fHandle.read(1)
            if not char: break  
            fRealRead = fRealRead + 1
            szBuffer = ('%.2X' % ord(char) )
            if fRealRead == 1:
                subResp = struct.pack( '>B', int(szBuffer,16) )
            else:
                subResp = subResp + struct.pack( '>B', int(szBuffer,16) )		
        
        if fRealRead > (2*regCount):
            fRealRead = fRealRead -1;
        # if file length is odd, append a space; not very sure.
        elif fRealRead%2:
            subResp = subResp + struct.pack( '>B', int('20',16) )
            fRealRead = fRealRead + 1
           		
        resp = struct.pack( '>B', func)
        szBuffer = ('%.2X' % (fRealRead + 2 ) )
        resp = resp + struct.pack( '>B', int( szBuffer, 16) )
        szBuffer = ('%.2X' % (fRealRead + 1 ) )
        resp = resp + struct.pack( '>B', int( szBuffer, 16) )
        resp = resp + struct.pack( '>B', int('06',16) )
        resp = resp + subResp	
	    
        fHandle.close()
    print msg
    printBuffer(buffer)
    sendResponse(sp,  ord(buffer[0]),  resp)

	
def handleWriteFiles(sp, buffer):
    func, byteCount = struct.unpack( '>BB', buffer[1:3] )
    msg = ('Handle Write files: %3.2d' % ord(buffer[0])) + (', %3.2d' % byteCount)
	
    resp = struct.pack( '>B', func)
    resp = resp + struct.pack( '>B', int('0D',16) )
    resp = resp + struct.pack( '>B', int('06',16) )
    resp = resp + struct.pack( '>B', int('00',16) )
    resp = resp + struct.pack( '>B', int('04',16) )
    resp = resp + struct.pack( '>B', int('00',16) )
    resp = resp + struct.pack( '>B', int('07',16) )
    resp = resp + struct.pack( '>B', int('00',16) )
    resp = resp + struct.pack( '>B', int('03',16) )
    resp = resp + struct.pack( '>B', int('06',16) )
    resp = resp + struct.pack( '>B', int('AF',16) )
    resp = resp + struct.pack( '>B', int('04',16) )
    resp = resp + struct.pack( '>B', int('BE',16) )
    resp = resp + struct.pack( '>B', int('10',16) )
    resp = resp + struct.pack( '>B', int('0D',16) )
    #resp = resp + struct.pack( '>B', int('E9',16) )
	
    print msg
    printBuffer(buffer)
    sendResponse(sp,  ord(buffer[0]),  resp)

def handleWriteFilesExt(sp, buffer):
    func, byteCount, refType, fileNumber, recNumber, regCount = struct.unpack( '>BBBHHH', buffer[1:10] )
    msg = ('Handle write files: %3.2d' % ord(buffer[0])) + (', %3.2d' % byteCount) + (', %3.2d' % recNumber)
    print msg
    printBuffer(buffer)
	
    if fileNumber == 0:
        fName = 'SRB_FW.srb'
    elif fileNumber == 1:
        fName = 'QTS_FW.qts'
    elif fileNumber == 2:
        fName = 'MENU.cbr'
    else:
        fName = 'COUNT000_W.csv'
		
    if recNumber == 0:
        fHandle = open(fName, 'w')
    else:
        fHandle = open(fName, 'r+')
    fHandle.seek(recNumber*244)
    
    for i in range(1, regCount*2 + 1):
        #char = struct.unpack( '>B', buffer[(9+i), 10+i] )
        char = chr(ord(buffer[9+i]))
        #asiiChar = chr(char)
        fHandle.write(char)
        szBuffer = ('%.2X' % ( ord(buffer[9+i]) ) )
        if i == 1:
            subResp = struct.pack( '>B', int(szBuffer,16) )
        else:
            subResp = subResp + struct.pack( '>B', int(szBuffer,16) )
  
    resp = struct.pack( '>B', func)
    resp = resp + struct.pack( '>B', byteCount)
    resp = resp + struct.pack( '>B', refType)
    resp = resp + struct.pack( '>H', fileNumber)
    resp = resp + struct.pack( '>H', recNumber)
    resp = resp + struct.pack( '>H', regCount)
    resp = resp + subResp

	# bufferLen = len(buffer)
	
    fHandle.close()
    sendResponse(sp,  ord(buffer[0]),  resp)
	
	
def handleModbus( sp, buffer ):
    # Find out what our packet is.  The command is either complete or it can't be executed on
    # The general pattern is, make sure we have all the bytes we need for this command
    # then check the CRC, then the address, then finally handle the command.

    # print 'handleModbus:', len(buffer)
    
    global addresses
        
    if len(buffer) >= 2:
        addr, func = struct.unpack( '>BB', buffer[0:2] )
        	
        if addr not in addresses:
        		print '-------------------------------------------------'
        		return ''
        	
        # read registers
        if func == 0x03:
            if len(buffer) >= 8:
                if checkCrc( sp, buffer[0:8] ):
                    if checkAddress( buffer[0] ):
                        handleReadRegisters( sp, buffer[0:8] )
        # read input register
        elif func == 0x04:
            if len(buffer) >= 8:
                if checkCrc( sp, buffer[0:8] ):
                    if checkAddress( buffer[0] ):
                        handleReadInputRegisters( sp, buffer[0:8] )            
        # write single register
        elif func == 0x06:      
            if len(buffer) >= 8:
                if checkCrc(sp,  buffer[0:8]):
                    if checkAddress(buffer[0]):
                        handleWriteRegister(sp,  buffer[0:8])    
		# write registers
        elif func == 0x10:
            if len(buffer) >= 10:
                bytecount = ord(buffer[6]) + 9
                if len(buffer) >= bytecount:
                    if checkCrc( sp, buffer[0:bytecount] ):
                        if checkAddress( buffer[0] ):
                            handleWriteRegisters( sp, buffer[0:bytecount] )
        elif func == 0x14:
            # handleReadFiles( sp, buffer[0:17] )
            if len(buffer) >= 12:
                handleReadFilesExt( sp, buffer[0:10] )
        elif func == 0x15:
            # handleWriteFiles( sp, buffer[0:18] )
            length = ord(buffer[2]) + 5
            if len(buffer) == length:
                handleWriteFilesExt( sp, buffer[0:length] )
            else:
                print "Truncated or Overflow 0x15 Command:"
                printBuffer( buffer )			
        # unknow function
        else:
            print 'Unknown function: ' + str(func) 
            print ' ',
            printBuffer( buffer, 1 )
        print '-------------------------------------------------'

    return ''


def ReadAddressFile( filename ):
    global addresses

    f = open( filename, 'rb' )
    lines = f.readlines()
    f.close()

    addresses = []

    for line in lines:
        if (len(line.strip()) > 0):
            addresses.append(int(line, 0))
    print 'Addresses: ', addresses
    

def ReadPortFile( filename ):
    f = open( filename, 'rb' )
    lines = f.readlines()
    f.close()

    port = 0
    baudrate = 9600

    for line in lines:
        pair = line.strip().split(':')
        if len(pair) <> 2:
            continue
        if pair[0].strip() == 'port':
            port = int(pair[1], 10)
        elif pair[0].strip() == 'baudrate':
            baudrate = int(pair[1], 10)

    return port, baudrate


def ReadRegisterFile( filename ):
    global registers

    f = open( filename, 'rb' )
    lines = f.readlines()
    f.close()

    registers = {}

    for line in lines:
        if line[0] == '#':
            continue
        idx = line.find( '#' )
        if idx > -1:
            line = line[0:idx]
        line = line.strip()
        if len(line) == 0:
            continue

        pair = line.split( ':' )
        key = int( pair[0], 0 )
        val = pair[1].strip().split( ' ' )

        registers[key] = val

    for key in registers.keys():
        print 'register: ', key
        print registers[key]

def ReadDeviceIdFile( filename ):
    global deviceids

    f = open( filename, 'rb' )
    lines = f.readlines()
    f.close()

    deviceids = {}

    for line in lines:
        if len(line.strip()) > 0:
            print 

          #  print line
            

def printFileExpt( filename ):
    print 'Error: no ' + filename + ' file exists or the file is invalid.'
    

def main():
    global addressFileTimeStamp
    global registerFileTimeStamp
    global deviceIdFileTimeStamp
    global recipeCounterFileTimeStamp
    global errorLogFileTimeStamp

    # open the serial port
    port, baudrate = ReadPortFile( 'port.txt' )
    sp = setupSerialPort( port, baudrate )

    lastFileCheck = 0.0
    firstRun = True

    buffer = ''

    while True:
        if (lastFileCheck + 30.0) < time.time():
            lastFileCheck = time.time()

            filename = 'address.txt'
            try:
                fileinfo = os.stat( filename )
                if addressFileTimeStamp != fileinfo[8]:
                    addressFileTimeStamp = fileinfo[8]
                    ReadAddressFile( filename )
            except:
                printFileExpt( filename )
                sys.exit()

            filename = 'register.txt'
            try:
                fileinfo = os.stat( filename )
                if registerFileTimeStamp != fileinfo[8]:
                    registerFileTimeStamp = fileinfo[8]
                    ReadRegisterFile( filename )
            except:
                if firstRun:
                    printFileExpt( filename )
                    
            filename = 'deviceid.txt'
            try:
                fileinfo = os.stat( filename )
                if deviceIdFileTimeStamp != fileinfo[8]:
                    deviceIdFileTimeStamp = fileinfo[8]
                    ReadDeviceIdFile( filename )
            except:
                if firstRun:
                    printFileExpt( filename )

            filename = 'COUNT000.csv'
            try:
                fileinfo = os.stat( filename )
                if recipeCounterFileTimeStamp != fileinfo[8]:
                    recipeCounterFileTimeStamp = fileinfo[8]
                    recipeCounterFileCRC = crc16.calcFileCRC( filename, 0xffff )
                    print "recipeCounterFileCRC: 0x%x" % recipeCounterFileCRC
                    if registers.has_key(0x8003):
                        szRecipeCRCBuffer = ('%.2X' % (recipeCounterFileCRC>>8) )
                        print "szRecipeCRCBuffer 1 = %s" % szRecipeCRCBuffer
                        registers[0x8003][0] = szRecipeCRCBuffer
                        szRecipeCRCBuffer = ('%.2X' % (recipeCounterFileCRC & 0x00FF) )
                        print "szRecipeCRCBuffer 2 = %s" % szRecipeCRCBuffer
                        registers[0x8003][1] = szRecipeCRCBuffer						
            except:
                if firstRun:
                    printFileExpt( filename )		

            filename = 'ERROR000.csv'
            try:
                fileinfo = os.stat( filename )
                if errorLogFileTimeStamp != fileinfo[8]:
                    errorLogFileTimeStamp = fileinfo[8]
                    errorLogFileCRC = crc16.calcFileCRC( filename, 0xffff )
                    print "recipeCounterFileCRC: 0x%x" % errorLogFileCRC
                    if registers.has_key(0x8002):
                        szErrorLogCRCBuffer = ('%.2X' % (errorLogFileCRC>>8) )
                        print "szErrorLogCRCBuffer 1 = %s" % szErrorLogCRCBuffer
                        registers[0x8002][0] = szErrorLogCRCBuffer
                        szErrorLogCRCBuffer = ('%.2X' % (errorLogFileCRC & 0x00FF) )
                        print "szErrorLogCRCBuffer 2 = %s" % szErrorLogCRCBuffer
                        registers[0x8002][1] = szErrorLogCRCBuffer						
            except:
                if firstRun:
                    printFileExpt( filename )					

            firstRun = False
                    
        bRead, buffer = readSerialPort( sp )
        if bRead:
            handleModbus( sp, buffer )


if __name__ == '__main__':
    main()
