# -*- coding: utf-8 -*-

import re
# print(re.match('www', 'www.runoob.com'))  # 在起始位置匹配
# print(re.match('com', 'www.runoob.com'))         # 不在起始位置匹配

line = "Cats are smarter than dogs"


matchObj = re.match( r'(.*) are (.*?) (.*)', line, re.M|re.I) 
if matchObj:
   cnt = len(matchObj.groups())
   print("matchObj.groups(): ", matchObj.groups())
   print("matchObj.groups() cnt: ", cnt)
   for index in range(1,cnt+1):
          str = "matchObj.group(%d): %s" %(index, matchObj.group(index))
          print(str)
else:
   print("No match!!")



matchObj = re.match(r'dogs', line, re.M|re.I)  #from the beginning.
if matchObj:
   print("match --> mathchObj.group(): ", matchObj.group())
else:
   print("No match!!!")


matchObj = re.search(r'than', line, re.M|re.I)  # from beginning to ending.
if matchObj:
       print("match --> mathchObj.group(): ", matchObj.group())
else:
   print("No match!!!")

line = "Cats are smarter than dogs";
searchObj = re.search( r'(.*) are (.*?) .*', line, re.M|re.I)
if searchObj:
       cnt = len(searchObj.groups())
       print("searchObj.groups(): ", searchObj.groups())
       print("searchObj.groups() cnt: ", cnt)
       for index in range(1, cnt+1):
              str = "searchObj.group(%d): %s" %(index, searchObj.group(index))
              print(str)

line = "Cats are smarter than dogs"
matchObj = re.match( r'(.*) are (.*?) .*', line, re.M|re.I)
if matchObj:
    print("matchObj.group() : ", matchObj.group())
    print("matchObj.group(1) : ", matchObj.group(1))
    print( "matchObj.group(2) : ", matchObj.group(2))
else:
    print("No match!!")