from bs4 import BeautifulSoup
import requests
import sys

class downloader(object):
    def __init__(self):
        #《笔趣看》网小说
        self.homepage = 'http://www.biqukan.com'

        #《一念永恒》
        self.target = '/1_1094'
        self.names = []
        self.urls = []
        self.nums = 0

    def get_download_url(self):
        resq = requests.get(url= str(self.homepage + self.target))
        #print(str(self.homepage + self.target))
        resq.encoding = 'gbk'
        html = resq.text
        div_bf = BeautifulSoup(html)
        listMenu = div_bf.find_all('div', class_='listmain')
        if listMenu:
            a_bf = BeautifulSoup(str(listMenu[0]))
        else:
            return;
        a = a_bf.find_all('a')

        self.nums = len(a[20:])
        for item in a[20:]:
            self.names.append(item.string)
            self.urls.append(self.homepage + item.get('href'))

    def get_contents(self, target):
        resp = requests.get(url=target)
        resp.encoding = 'gbk'
        html = resp.text
        bf = BeautifulSoup(html)
        texts = bf.find_all('div', class_ = 'showtxt')
        result = ''
        if len(texts):
            result = texts[0].text.replace('\xa0'*8,'\n\n')
        return result

    def writer(self, name, path, text):
        write_flag = True
        with open(path, 'a', encoding='utf-8') as f:
            f.write(name + '\n')
            f.writelines(text)
            f.write('\n\n')

if __name__ == '__main__':
    dl = downloader()
    dl.get_download_url()
    print('《一年永恒》开始下载：')
    for i in range(dl.nums):
        #print("url: ", dl.urls[i])
        #dl.writer(dl.names[i], '一念永恒.txt', dl.get_contents(dl.urls[i]))
        dl.writer(dl.names[i], str(dl.names[i] + '.txt'), dl.get_contents(dl.urls[i]))
        sys.stdout.write("  已下载:%.3f%%" %  float(i/dl.nums) + '\r')
        sys.stdout.flush()
    print('《一年永恒》下载完成')