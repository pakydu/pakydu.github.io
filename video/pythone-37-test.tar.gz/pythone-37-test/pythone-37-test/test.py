import requests
import json

print("test...")

BASE_URL="http://10.161.93.24"

r = requests.options(BASE_URL)
print(r.headers)