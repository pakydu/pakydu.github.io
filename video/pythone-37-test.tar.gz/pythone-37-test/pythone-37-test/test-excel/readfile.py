import xlrd

xlsx = xlrd.open_workbook('D:/work2/doc/pythone-37-test/JsonCpp.xlsx')

table = xlsx.sheet_by_index(0)

# val = table.cell_value(3,1)
# print(val)

for n in range(0, table.nrows):
    print('-----------Row: %d-----------------' % n)
    print(table.cell(n,0).value)
    print(table.cell(n,1).value)
    print(table.cell(n,2).value)
    