import requests
import json
import hashlib   #md5
import getpass
import random


Http_header = {
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
    }


def getSSid(control_ip):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    print(base_url)
    payload = {'m':'{"jsonrpc":"2.0","method":"GetSessionID","id":"1"}'}
    rsq = requests.get(base_url, params=payload, headers= Http_header)
    print("income...")
    print()
    decodejson = json.loads(rsq.text) 
    if (rsq.status_code == 200):
        if "error" in decodejson :
            print("Error:", rsq.text)
            return ""
        else:
            if "sid" not in decodejson['result']:
                print("Can't get the sid.")
                return ""
            else:
                return decodejson["result"]["sid"]
    else:
        return ""
    

#m: {"jsonrpc":"2.0","method":"Login","params":{"username":"user","password":"3fad88420a85798e4e41157311047fc0","sid":"cc15d507-cb4a-4a96-bcd3-8545e0af1b23"},"id":"19"}
def login(control_ip, sid):
    username = input("input username:")
    #passwd = input("input username:")
    passwd =  getpass.getpass("input passwd:")
    md = hashlib.md5()
    #passwd="Emerson01"
    md.update(passwd.encode('UTF-8'))
    print(md.hexdigest())
    print("----------sha256---------")
    s256 = hashlib.sha256()
    s256.update(passwd.encode('UTF-8'))
    print(s256.hexdigest())

    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"Login",' + '"params":{"username":"' + username +'","password":"' + md.hexdigest() + '","sid":"' + sid +'"},"id":"19"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    decodejson = rsq.json()
    if (rsq.status_code == 200):
        if "error" in decodejson :
            print("Error:", rsq.text)
            return False
        else:                
            return True
    else:
        return False
def NewLogin(control_ip, sid):
    username = input("input username:")
    #passwd = input("input username:")
    passwd =  input("input passwd:") #getpass.getpass("input passwd:")
    print(passwd)
    md = hashlib.md5()
    #passwd="Emerson01"
    md.update(passwd.encode('UTF-8'))
    print(md.hexdigest())
    print("----------sha256 new login---------")
    md5Passwd = md.hexdigest()
    print("Append the sid to the md5")
    md5Passwd = md5Passwd + sid
    print(passwd)
    print("md5Passwd: ", md5Passwd)
    s256 = hashlib.sha256()
    s256.update(md5Passwd.encode('UTF-8'))
    print(s256.hexdigest())

    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"Login",' + '"params":{"key":"' + username +'","value":"' + s256.hexdigest() + '","sid":"' + sid +'"},"id":"19"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    decodejson = rsq.json()
    if (rsq.status_code == 200):
        if "error" in decodejson :
            print("Error:", rsq.text)
            print("Login Failed.")
            return False
        else:
            print(decodejson)
            print("Login OK.")               
            return True
    else:
        print(decodejson)
        print("Login Failed.")
        return False


#m: {"jsonrpc":"2.0","method":"ApplyAdf","params":{"storage":"usb2","file":"/c16AIBoard.adf","sid":"40f2abe2-f677-4055-96be-b746a4b748b0"},"id":"114"}
def AddAdf(control_ip, sid):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"ApplyAdf2",' + '"params":{"storage":"usb2","file":"/c16AIBoard.adf","sid":"' + sid +'"},"id":"19"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    print(rsq.text)

#m: {"jsonrpc":"2.0","method":"ApplyFeatureFile","params":{"storage":"usb2","file":"/License_SR-37-3C-17.fsf","sid":"40f2abe2-f677-4055-96be-b746a4b748b0"},"id":"114"}
def AddFsf(control_ip, sid):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"ApplyFeatureFile",' + '"params":{"storage":"usb2","file":"/License_SR-37-3C-17.fsf","sid":"' + sid +'"},"id":"19"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    print(rsq.text)

#m: {"jsonrpc":"2.0","method":"ApplyFloorplan","params":{"storage":"usb2","file":"/c16AIBoard.adf","sid":"40f2abe2-f677-4055-96be-b746a4b748b0"},"id":"114"}
def AddFloorplan(control_ip, sid):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"ApplyFloorplan",' + '"params":{"storage":"usb2","file":"/XR75 status screen.zip","sid":"' + sid +'"},"id":"19"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    print(rsq.text)



"""
Request URL:http://10.161.93.24/cgi-bin/mgw.cgi
Request Method:POST
Status Code:200 OK
Remote Address:10.161.93.24:80
Referrer Policy:no-referrer-when-downgrade
Response Headers
view source
Content-Type:application/json; charset=utf-8
Date:Wed, 29 Nov 2017 02:54:35 GMT
Server:lighttpd/1.4.35
Transfer-Encoding:chunked
Request Headers
view source
Accept:*/*
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Connection:keep-alive
Content-Length:174
Content-Type:application/x-www-form-urlencoded; charset=UTF-8
Host:10.161.93.24
Origin:http://10.161.93.24
Referer:http://10.161.93.24/
User-Agent:Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36
X-Requested-With:XMLHttpRequest
Form Data
view source
view URL encoded
m:{"jsonrpc":"2.0","method":"GetSystemInventory","params":{"sid":"f0dd7640-de1a-45ef-ab1c-27c4590db238"},"id":"8"}
"""
def getAppslist(ip, sessionid):
        base_url="http://" + ip + "/cgi-bin/mgw.cgi"
        icnt = random.randint(1000,10000)
        param = '{"jsonrpc":"2.0","method":"GetSystemInventory","params":{"sid":"' + sessionid + '"},"id":"' + str(icnt) +'"}'
        print(param)
        payload = {'m':param}
        rsq = requests.post(base_url, data=payload, headers= Http_header)
        #yprint(rsq.text)
        decodejson = rsq.json(); #json.loads(rsq)
       	#print decodejson['result']['aps']
       	return decodejson['result']['aps']

#m: {"jsonrpc":"2.0","method":"SetPointValues","params":{"points":[{"ptr":"3470707853:BACnetPort","val":"47809"}],"sid":"616fdb9d-b17c-4bf0-8365-e075c9c62ab9"},"id":"45"}
def disableServicePort(control_ip, sid):
    #step 1: get the "System Settings" instance IID
    systemSetting_iid = ""
    apps_dict = getAppslist(control_ip, sid)
    for app in apps_dict:
        #if (app['appname'] == 'System Settings') or (app['appname'] == 'System Sett'):
        if (app['apptype'] == 'SystemSettings'):
            systemSetting_iid = app['iid']
            break

    #step 2: create "SetPointValues" message for http request.
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    icnt = random.randint(1000,10000)
    flag1 = input("Do you want to disable  BACnetEth0Port(y/n) ----> ")
    str1 = "0" if flag1 == 'y' else "47808"
    flag2 = input("Do you want to disable  BACnetEth1Port(y/n) ----> ")
    str2 = "0" if flag2 == 'y' else "47808"
    flag3 = input("Do you want to disable  MonitoringPort(y/n) ----> ")
    str3 = "0" if flag3 == 'y' else "3001"
    flag4 = input("Do you want to disable  LegacyClientPort(y/n) ----> ")
    str4 = "0" if flag4 == 'y' else "1025"
    body_setBacnetPort = '{"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"' + sid + '","points":[{"ptr":"' + systemSetting_iid + ':BACnetPort","val":"' + str1 + '"}' + \
                                                                                                             ',{"ptr":"' + systemSetting_iid + ':BACnetPortEth1","val":"' + str2 + '"}' +\
                                                                                                             ',{"ptr":"' + systemSetting_iid + ':MonitoringPort","val":"' + str3 + '"}'\
                                                                                                             ',{"ptr":"' + systemSetting_iid + ':LegacyClientPort","val":"' + str4 + '"}'\
                                                          ']},"id":"' + str(icnt) +'"}'
        
    print(body_setBacnetPort)
    payload = {'m':body_setBacnetPort}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    
    decodejson = rsq.json() #json.loads(rsq)
    print(decodejson)
    if "error" in decodejson :
        print("Error:", rsq.text)
    else:
        result = decodejson['result']
        print("result: ", result)
  

if __name__ == "__main__":
    #define func map
    func_map = { 
        '1':AddAdf,
        '2':AddFsf,
        '3':AddFloorplan,
        '4':disableServicePort,
        '5':NewLogin
        #'100':lambda :print('Not support this function')
    }
    #func = swicher.get(x,'4')


    control_ip = input("Input your SS' IP  ----> ")
    print(control_ip)
    sid = getSSid(control_ip)
    if (len(sid) == (32+4)):
        print("get sid OK.")
        while True:
            if login(control_ip, sid):
                while True:
                    print("\t\t\t install Adf   --->  1")
                    print("\t\t\t install fsf   --->  2")
                    print("\t\t\t install Floorplan   --->  3")
                    print("\t\t\t test  ServicePort  --->  4")
                    print("\t\t\t test  NewLogin  --->  5")
                    print("\t\t\t Exit   --->  0")
                    index = input("Choice fun num: ")
                    if (len(index) > 0):
                    
                        if not index.isnumeric():
                            print('Not support this function')
                        if index == '0':
                            print("Bye....")
                            exit(0)
                        else:
                            func = func_map.get(index, '100')
                            if (index == '100'):
                                print('Not support this function')
                            else:
                                func(control_ip, sid)
                    else:
                        index = "100"
            else:
                print("login failed...")
        else:
            print("get sid failed: " + sid) 

