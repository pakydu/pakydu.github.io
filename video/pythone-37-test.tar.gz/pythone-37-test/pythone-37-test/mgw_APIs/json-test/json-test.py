#!/usr/bin/python3

# json.dumps(): 对数据进行编码。  python data        --->  Json format string.
# json.loads(): 对数据进行解码。  Json format string --->   python data

import json

data = {
    'no':1,
    'name':'paky',
    'url':'hppt://pakytest.cn'
}

json_str = json.dumps(data)
print("Python RAW data:", repr(data))
print("Json Obj:", json_str)
print("json_str type:", type(json_str))

data2 = json.loads(json_str)
print("data2 type:", type(data2))
print("data[name]:", data2['name'])
