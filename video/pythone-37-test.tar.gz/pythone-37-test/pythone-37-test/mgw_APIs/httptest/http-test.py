#！/usr/bin/python3

import requests
import json 

host = 'http://httpbin.org/'
endpoint = 'get'

url = ''.join([host, endpoint])
# params = {"show_env":"1"}
# rsp = requests.get(url=url, params=params)

# print(type(rsp.text))
# print(rsp.text)
# print(type(rsp.json()))
# print(rsp.json())
# print(rsp.status_code)
# print(rsp.reason)
# print(type(rsp.cookies))

# print('-----------------')
# print(rsp.encoding)
# print(rsp.request.headers)
# print(rsp.raw.read())

headers = {"User-Agent":"paky test headers"}
params = {"show_env":"1"}

rsp = requests.get(url, headers=headers, params=params)
rspData = eval(rsp.text)
print(rspData)
print(rspData['headers']['User-Agent']) #paky test headers
print(rsp.url)  #http://httpbin.org/get?show_env=1
