#!/usr/bin/python3


import requests
import json 

host = 'http://httpbin.org/'
endpoint = 'post'

url = ''.join([host,endpoint])
# data = {'key1':'value1', 'key2':'vlaue2'}

# rsp = requests.post(url, data=data)
# print(rsp.text)
# print(rsp.url)

files = {
    'file':open('test.log','rb')
}

rsp = requests.post(url, files=files)
print(rsp.text)