#!/usr/bin/python3

import xlrd
import xlsxwriter
import os

filename='Paky.xls'
filePath = os.path.join(os.getcwd(), filename)
print("filename:",filePath)
xl = xlrd.open_workbook("Paky.xls")

print("Sheet names:",xl.sheet_names())


workbook = xlsxwriter.Workbook("pakytest.xlsx")

worksheet = workbook.add_worksheet('s1')

bold = workbook.add_format({'bold':1})

#prepare data
data = [
    ['closed','active','reopen','NT'],
    [1012, 109, 123, 131],
]

#write data
worksheet.write_row('A1', data[0], bold)
worksheet.write_row('A2', data[1])

#generate the picture.
chart_col = workbook.add_chart({'type':'pie'})

chart_col.add_series({
    'name':'Bug Analysis',
    'categories':'=s1!$A$1:$D$1',
    'values':'=s1!$A$2:$D$2',
    'points': [
        {'fill':{'color':'#00CD00'}},
        {'fill':{'color':'red'}},
        {'fill':{'color':'yellow'}},
        {'fill':{'color':'gray'}},
    ],
}
)

#set the title, x and Y.
chart_col.set_title({'name':'Bug Analysis'})
chart_col.set_style(10)

worksheet.insert_chart('B10', chart_col, {'x_offset':0, 'y_offset':0})
workbook.close()