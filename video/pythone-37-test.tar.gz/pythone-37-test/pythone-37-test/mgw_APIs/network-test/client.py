#!/usr/bin/python3

import socket 
import sys 
from time import ctime


sockClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

host = "127.0.0.1" #socket.gethostname()
port = 9999

sockClient.connect((host, port))
while True:
    data = input('>>').strip()
    if not data:
        break
    sockClient.send(data.encode('utf-8'))
    data = sockClient.recv(1024)
    if not data:
        break
    print(data.decode('utf-8'))
sockClient.close()
