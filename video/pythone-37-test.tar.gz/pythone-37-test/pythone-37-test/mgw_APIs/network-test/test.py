#!/usr/bin/python3
import sys
import json
from math import pi

# print(sys.version_info)

# squares = []

# for x in range(10):
#     squares.append(x**2)
# print(squares)

# #lambda x: x+1, lambda是个表达式。
# f = lambda x,y,z: x+y+z
# print(f(1,2,3))

# L = [lambda x: x+2, lambda x: x*2, lambda x: x**2]
# print("L=", L[0](1), L[1](2), L[2](3) )

# l = lambda: lambda x: x+5
# b = l()
# print("b=",b(5))
# print("==",(l())(5))

# def inc(x):
#     return x + 10

# ls = [1,2,3]
# print( list(map(inc, ls)))
# print("map lambda:",list(map(lambda x: x+10, ls)))

# ls2 = [(x,y) for x in [1,2,3] for y in [3,1,4] if x!=y]
# print("ls2:", ls2)

# ls3 = [str(round(pi, i)) for i in range(1,100)]
# print(ls3)

# #集合类型
# a = {x for x in 'abracadabra' if x not in 'bcd'}
# print(a)


# #字典
# keyVal = {'a':1, 'b':2, 'c':3}
# for k, v in keyVal.items():
#     print(k,v)


# for i,v in enumerate(['a','b','c'],start = 1):
#     print(i, v)

# #path for the module research.
# print(sys.path)

# print(dir(sys))


# #print("__path__:", __path__)
# #josn format data
# f = open('test.log', 'w')
# #x = [1,'simple', 'list']
# json.dump([1,'simple', 'list'],f)
# f.close()

# f = open('test.log', 'r')
# x = json.load(f)
# print(x)

#exception handle
while True:
    try:
        x = int(input("Please enter a number:"))
        break
    except ValueError:
        print("Oops! That was no valid number. Try again...")

class MyError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

try:
    raise MyError(2*2)
except MyError as e:
    print('My exception value:', e.value)

