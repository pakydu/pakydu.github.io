#!/usr/bin/python3

from socket import *
import sys 
import time


servSock = socket(AF_INET, SOCK_STREAM)

host = "0.0.0.0" #socket.gethostname()
port = 9999
#print("host name:", host)

servSock.setsockopt(SOL_SOCKET, SO_REUSEADDR,1)
servSock.bind((host, port))

servSock.listen(5)

while True:
    print("Service start, waiting client...")
    client,addr = servSock.accept()
    print("connect from: %s" % str(addr))
    while True:
        try:
            data = client.recv(1024)
        except Exception:
            print("disconnect from client:",addr)
            break
        print("client send data:", data.decode('utf-8'))
        if not data:
            break
        msg = time.strftime("%Y-%m-%d %X")
        msg1 = '[%s]:%s' % (msg, data.decode('utf-8'))
        client.send(msg1.encode('utf-8'))
    client.close()
servSock.close()
