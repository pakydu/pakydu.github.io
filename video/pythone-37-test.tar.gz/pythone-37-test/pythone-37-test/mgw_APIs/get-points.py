import requests
import json
import hashlib   #md5
import getpass


Http_header = {
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
    }


def getSSid(control_ip):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    print(base_url)
    payload = {'m':'{"jsonrpc":"2.0","method":"GetSessionID","id":"1"}'}
    rsq = requests.get(base_url, params=payload, headers= Http_header)
    print("income...")
    print()
    decodejson = json.loads(rsq.text) 
    print(decodejson["result"]["sid"])
    return decodejson["result"]["sid"]

#m: {"jsonrpc":"2.0","method":"Login","params":{"username":"user","password":"3fad88420a85798e4e41157311047fc0","sid":"cc15d507-cb4a-4a96-bcd3-8545e0af1b23"},"id":"19"}
def login(control_ip, sid):
    username = input("input username:")
    #passwd = input("input username:")
    passwd =  getpass.getpass("input passwd:")
    md = hashlib.md5()
    #passwd="Emerson01"
    md.update(passwd.encode('UTF-8'))
    print(md.hexdigest())
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"Login",' + '"params":{"username":"' + username +'","password":"' + md.hexdigest() + '","sid":"' + sid +'"},"id":"19"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    if (rsq.status_code == 200):
        return True
    else:
        return False


#m: {"jsonrpc":"2.0","method":"GetPointValues","params":{"points":[{"ptr":"889904477:AppName"},{"ptr":"889904477:Mode"},{"ptr":"889904477:LogTotalSamples"},{"ptr":"889904477:LogInterval"},{"ptr":"889904477:LogDuration"},{"ptr":"889904477:DefaultLogGrp"},{"ptr":"889904477:ENABLE"},{"ptr":"889904477:ArchiveEnable"},{"ptr":"889904477:ArchiveNoticePercent"},{"ptr":"889904477:ArcDst"},{"ptr":"889904477:ArcPerAlmDly"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Archive Percentage Full"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Category"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Display Message"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Repeat Rate"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Monitor Alarm"}],"sid":"c3dc02e0-7473-40a0-9d76-1e547de635ac"},"id":"118"}
def GetPointValues(control_ip, sid, icnt):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"GetPointValues",' + '"params":{"points":[{"ptr":"889904477:AppName"},{"ptr":"889904477:Mode"},{"ptr":"889904477:LogTotalSamples"},{"ptr":"889904477:LogInterval"},{"ptr":"889904477:LogDuration"},{"ptr":"889904477:DefaultLogGrp"},{"ptr":"889904477:ENABLE"},{"ptr":"889904477:ArchiveEnable"},{"ptr":"889904477:ArchiveNoticePercent"},{"ptr":"889904477:ArcDst"},{"ptr":"889904477:ArcPerAlmDly"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Archive Percentage Full"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Category"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Display Message"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Repeat Rate"},{"ptr":"889904477:LGRALMARCPER~Archive Percentage Full~Monitor Alarm"}],"sid":"' + sid +'"},"id":"' + str(icnt) +'"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    print(rsq.text)

#m: {"jsonrpc":"2.0","method":"SetPointValues","params":{"points":[{"ptr":"2169768155:OutdoorTemp","val":"0.5555555555555556"}],"sid":"b1107581-fbf8-45a5-81f9-af5c8a1e1be7"},"id":"99"}
def SetPointValues(control_ip, sid, icnt):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"SetPointValues",' + '"params":{"points":[{"ptr":"2169768155:OutdoorTemp","val":"' + str(icnt%2) + '"}],"sid":"' + sid +'"},"id":"' + str(icnt) +'"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    print(rsq.text)



#m={"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"8c6d01d6-3b64-434f-aea8-87e6fd7569a4","points":[{"ptr":"3677319964:LogInterval","val":"15"},{"ptr":"3677319964:LogDuration","val":"13.00"},{"ptr":"3677319964:ArchiveEnable","val":"1"},{"ptr":"3677319964:ArchiveNoticePercent","val":"79"},{"ptr":"3677319964:ArcPerAlmDly","val":"62"},{"ptr":"3677319964:LGRALMARCPER~Archive Percentage Full~Archive Percentage Full","val":"Non-Critical"},{"ptr":"3677319964:LGRALMARCPER~Archive Percentage Full~Repeat Rate","val":"60"}]},"id":"166"}
def SetLogPointValues(control_ip, sid, icnt):
    base_url="http://" + control_ip + "/cgi-bin/mgw.cgi"
    param = '{"jsonrpc":"2.0","method":"SetPointValues",' + '"params":{"points":[{"ptr":"3677319964:LogInterval","val":"15"},{"ptr":"3677319964:LogDuration","val":"' + str((icnt%2) + 1) + '"},{"ptr":"3677319964:ArchiveEnable","val":"1"},{"ptr":"3677319964:ArchiveNoticePercent","val":"79"},{"ptr":"3677319964:ArcPerAlmDly","val":"62"},{"ptr":"3677319964:LGRALMARCPER~Archive Percentage Full~Archive Percentage Full","val":"Non-Critical"},{"ptr":"3677319964:LGRALMARCPER~Archive Percentage Full~Repeat Rate","val":"60"}],"sid":"' + sid +'"},"id":"' + str(icnt) +'"}'
    print(param)
    payload = {'m':param}
    rsq = requests.post(base_url, data=payload, headers= Http_header)
    print(rsq.text)

if __name__ == "__main__":

    control_ip = input("Input your SS' IP  ----> ")
    print(control_ip)
    sid = getSSid(control_ip)
    if (len(sid) == (32+4)):
        print("get sid OK.")
        cnt = input("Input testing times  ----> ")
        if (login(control_ip, sid)):
            for i in range(1, int(cnt)+1):
                SetLogPointValues(control_ip, sid, i)
        else:
            print("login failed...")
    else:
        print("get sid failed: " + sid) 

