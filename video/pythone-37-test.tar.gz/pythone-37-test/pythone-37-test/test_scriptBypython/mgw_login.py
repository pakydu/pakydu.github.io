"""
"  This script is for enable/disable SSH when the current Firmware is BATE or FIN
"  This is just for testing in our local, please don't publish it.
"  2017-11-30.
"""

import os
import sys
import re
import timeit
import time
import random
import urllib    
import urllib2
import httplib
import json
import hashlib   #md5

#define the http head data members:
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
Encoding = 'gzip, deflate'
XWith = 'XMLHttpRequest'
print "This script will help us to enable Site Supervisor SSH, and try to get its password"



#m: {"jsonrpc":"2.0","method":"Login","params":{"sid":"c7375ae5-de4f-4347-b5cf-e4f0b3f028de","username":"user","password":"3fad88420a85798e4e41157311047fc0"},"id":"1580"}
def login(ip):
       	url_perfix = 'http://' + ip
       	url = url_perfix + '/cgi-bin/mgw.cgi'

       	Origin = url_perfix
       	Referer = url_perfix + '/'
       	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}
       	
       	body_getVer = 'm={"jsonrpc":"2.0","method":"Login","params":{"sid":"57705691-9133-401c-8c17-73944b087646","username":"user","password":"3fad88420a85798e4e41157311047fc0"},"id":"3"}'
       	
       	req = urllib2.Request(url, body_getVer, headers)
       	response = urllib2.urlopen(req)
       	resp_data = response.read()

       	decodejson = json.loads(resp_data)
       	print decodejson['result']['status']
       	print decodejson['result']['permissions']



        
#main active:

SS_ip = raw_input("\n ---> Please input your SS ip: ")
login(SS_ip)
