#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import codecs

print 'args operation...'


if __name__ == '__main__':
    print len(sys.argv)
    for arg in sys.argv:
        print arg


#write utf-8 char 1
a = unicode.encode(u'你好','utf-8')
print a.decode


f = codecs.open('3.txt', 'w', 'utf-8')
print f.mode

f.write(u'你好吗？')
f.close()

f = codecs.open('3.txt', 'r', 'utf-8')
print f.encoding
print f.read()
f.close
