# -*- coding: cp936 -*-
import struct
 
import array
import binascii
import ctypes
 
values = (1, 'abcde', 2)
s = struct.Struct('<I5sI')
packed_data = s.pack(*values)

print 'ԭʼֵ:', values
print '��ʽ��:',s.format
print 'ռ���ֽ�:',s.size
print '������:', binascii.hexlify(packed_data)


#packed_data = binascii.unhexlify(b'01000000616263646500000002000000')
 
#s = struct.Struct('I 5s I')
unpacked_data = s.unpack(packed_data)
print '������:', unpacked_data

x,y,z = s.unpack(packed_data)

print 'xyz', x,y,z



s = struct.Struct('I 2s f')
values = (1, 'ab'.encode('utf-8'), 2.7)
print 'ԭʼֵ:', values
 
print
print'ʹ��ctypesģ��string buffer'
 
b = ctypes.create_string_buffer(s.size)
print 'ԭʼbuffer :', binascii.hexlify(b.raw)
s.pack_into(b, 0, *values)
print '������д�� :', binascii.hexlify(b.raw)
print '���  :', s.unpack_from(b, 0)
 
print
print 'ʹ��arrayģ��'
 
a = array.array('b', b'\0' * s.size)
print 'ԭʼֵ :', binascii.hexlify(a)
s.pack_into(a, 0, *values)
print '���д�� :', binascii.hexlify(a)
print '���  :', s.unpack_from(a, 0)



#read file
registers = {}
def ReadRegisterFile( filename ):
    global registers

    f = open( filename, 'rb' )
    lines = f.readlines()
    f.close()

    registers = {}

    for line in lines:
        if line[0] == '#':
            continue
        idx = line.find( '#' )
        if idx > -1:
            line = line[0:idx]
        line = line.strip()
        if len(line) == 0:
            continue

        pair = line.split( ':' )
        key = int( pair[0], 0 )
        val = pair[1].strip().split( ' ' )

        registers[key] = val

    for key in registers.keys():
        print 'register: ', key
        print registers[key]

if __name__ == '__main__':
    ReadRegisterFile('register.txt')
