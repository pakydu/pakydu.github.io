import web

urls = (
    '/index', 'index',
    '/blog/\d+', 'blog',
    '/(.*)', 'hello'            
)

app = web.application(urls, globals())


class index:
    def GET(self):
        query = web.input()
        return query

class blog:
    def GET(self):
        return web.ctx.env

    def POST(self):
        data = web.input()
        return data

class hello:
    def GET(self, name):
        return open(r'2.html').read()


if __name__ == "__main__":
    app.run()
