# -*- coding: UTF-8 -*-

import web
import MySQLdb
import MySQLdb.cursors

render = web.template.render('templates')

urls = (
    '/article', 'article',
    '/index', 'index',
    '/blog/\d+', 'blog',
    '/(.*)', 'hello'            
)

app = web.application(urls, globals())


class index:
    def GET(self):
        query = web.input()
        return query

class blog:
    def GET(self):
        return web.ctx.env

    def POST(self):
        data = web.input()
        return data

class hello:
    def GET(self, name):
        return render.hellotest("")


class article:
    def GET(self):
        conn=MySQLdb.connect(host='127.0.0.1', user='root', passwd='root', db='pakytest', port=3306, cursorclass=MySQLdb.cursors.DictCursor)
        cur=conn.cursor()
        cur.execute('select * from articles')
        r = cur.fetchall()
        cur.close()
        conn.close()
        print type(r)
        print r
        return render.article(r)

if __name__ == "__main__":
    app.run()
