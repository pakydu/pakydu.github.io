import socket


client = socket.socket()

ip_port = ("127.0.0.1", 8899)

client.connect(ip_port)

data = client.recv(1024)

print data

client.close()
