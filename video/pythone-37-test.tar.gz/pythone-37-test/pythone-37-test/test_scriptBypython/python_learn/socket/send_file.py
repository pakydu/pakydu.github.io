import socket

sk = socket.socket()

ip_port = ('127.0.0.1', 9999)

sk.connect(ip_port)


#open file and send raw data to service
with open('send_file.py', 'rb') as f:
    for i in f:
        sk.send(i)

sk.send('quit')

sk.close()
