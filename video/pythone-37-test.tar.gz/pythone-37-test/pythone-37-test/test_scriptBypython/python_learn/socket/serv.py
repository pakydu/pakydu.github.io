import socket

sk = socket.socket()

ip_port = ("127.0.0.1", 8899)

sk.bind(ip_port)


sk.listen(5)

while True:
    print 'waiting connect...'
    conn, addr = sk.accept()



    msg = 'Hello world'

    conn.send(msg)


    conn.close()
