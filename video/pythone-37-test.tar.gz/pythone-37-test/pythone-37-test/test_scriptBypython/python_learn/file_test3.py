#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import ConfigParser

cfg = ConfigParser.ConfigParser()

cfg.read('file.ini')

for sec in cfg.sections():
    print sec
    print cfg.items(sec)

#Add new option
cfg.set('userinfo', 'email', 'paky@123.com')

for sec in cfg.sections():
    print sec
    print cfg.items(sec)


#Add new section
#cfg.set('userinfo2', 'email', 'paky@123.com')

#for sec in cfg.sections():
#    print sec
#    print cfg.items(sec)

#remove option
cfg.remove_option('userinfo', 'email')

for sec in cfg.sections():
    print sec
    print cfg.items(sec)
