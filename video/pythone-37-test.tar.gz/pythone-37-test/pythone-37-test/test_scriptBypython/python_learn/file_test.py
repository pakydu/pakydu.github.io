#!/usr/bin/python

print 'file operation...'

f = open('1.txt', 'w')
f.write("test file write\n")
f.flush()
f.write("test file write2\n")
f.close()

f = open("1.txt", 'r')
print "read line by line:"
print f.readline()
print f.readline()

print "read all"
f.seek(0,0)
print f.read()
print 'tell:', f.tell()

print "read lines"
f.seek(0,0)
list_c = f.readlines()
print list_c
print len(list_c[0])


print "read by iter"
f.seek(0,0) # os.SEEK_SET = 0, os.SEEK_CUR = 1, os.SEEK_END = 2
iter_f = iter(f)
for it in iter_f:
    print it


print 'wirte file 1'
L = ['hello\n', 'world\n','xyc\n', 'abc\n']
f = open('2.txt', 'w')
f.writelines(L)
f.close()

f = open("2.txt", 'r')
print f.read()
f.close()

