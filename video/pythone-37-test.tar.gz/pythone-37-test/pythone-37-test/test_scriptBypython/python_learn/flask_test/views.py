from flask import Flask

app = Flask(__name__)

import logic


@app.route('/')
def home_page():
    home_data = logic.get_home()
    return home_data

@app.route('/books')
def books():
    books_data = logic.get_books()
    return books_data

@app.route('/book/<string:book_id>')
def book(book_id):
    book_data = logic.get_book(book_id)
    return book_data

@app.route('/studends')
def studends():
    students_data = logic.get_studends()
    return students_data

@app.route('/studend/<string:studend_id>')
def student(studend_id):
    studend_data = logic.get_studend(studend_id)
    return studend_data


if __name__ == '__main__':
    app.run()
