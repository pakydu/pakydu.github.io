# coding=utf-8

def get_home():
    return 'data of home page'
    
def get_books():
    return "list of books basic info"

def get_book(book_id):
    return "detailed info of book: {}".format(book_id)

def get_studends():
    return "list of studends basic info"
    
def get_studend(studend_id):
    return "detailed info of studend: {}".format(studend_id)