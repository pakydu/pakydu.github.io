from flask import Flask

app = Flask(__name__)


@app.route('/')
def home_page():
    return 'data of home page'

@app.route('/books')
def books():
    return 'all books list'

@app.route('/book/<string:book_id>')
def book(book_id):
    return 'return data of a book: {}'.format(book_id)

@app.route('/studends')
def studends():
    return 'all studends list'

@app.route('/studend/<string:studend_id>')
def student(studend_id):
    return 'return data of a studend: {}'.format(studend_id)


@app.route('/hello')    
def hello_worlk():
    return 'Hello World!'

if __name__ == '__main__':
    app.run()
