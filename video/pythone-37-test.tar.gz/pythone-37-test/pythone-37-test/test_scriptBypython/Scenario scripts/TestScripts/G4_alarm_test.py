#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import time
from datetime import datetime, tzinfo

#alarm test by cgi methods "MuteAlarm","AcknowledgeAlarm","ResetAlarm" by Dancy Yue on 12/14/16
print '\n'
print "---------------------------------"

def addconfigure(ip):

	#####################################################
	url_1 = 'http://'
	url_2 = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1438312968239'
	url = url_1 + ip + url_2
	url_x = url_1 + ip + '/cgi-bin/mgw.cgi'
	Referer = 'http://' + ip + '/'
	Origin = 'http://' + ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'

	body_sid = 'json=%7B%22lastMessageHash%22%3Anull%2C%22userName%22%3A%22user%22%2C%22passwordHash%22%3A%221a1dc91c907325c69271ddf0c944bc72%22%2C%22objType%22%3A%22LoginRequest%22%2C%22messageHash%22%3A%2245734895739857964%22%2C%22salt%22%3A%22abcdefghijk%22%7D'
	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}

	req = urllib2.Request(url, body_sid, headers)
	response = urllib2.urlopen(req)
	the_response = response.read()


	#get SID
	body_13 = re.search(r"sid\"\:\"(.*)\"\}\,\"i", the_response)

	for j in range(0, 65536):

		#查询所有的alarm
		body_get_alarm = 'm={"jsonrpc":"2.0","method":"GetAlarms","params":{"sid":"' + body_13.group(1) + '"},"id":"9"}'

		req = urllib2.Request(url_x, body_get_alarm, headers)
		#get response
		response = urllib2.urlopen(req)   
		the_response = response.read()  

		#提取所有的uid并保存list,uid":"12","unitnum“
		uid_get = re.findall(r"uid\"\:\"(\d+)\"\,\"unitnum", the_response)

		#print uid_get
		for uid_alarm in uid_get:
			
			#Mute Alarm
			body_MuteAlarm = 'm={"jsonrpc":"2.0","method":"MuteAlarm","params":{"sid":"' + body_13.group(1) + '","uid":"' + uid_alarm + '","username":"user","unitnum":"1","devicetype":"SS"},"id":"299"}'
			req = urllib2.Request(url_x, body_MuteAlarm, headers)

			#get response
			response = urllib2.urlopen(req) 
			the_response = response.read()        
			
			#Acknowledge Alarm
			body_AcknowledgeAlarm = 'm={"jsonrpc":"2.0","method":"AcknowledgeAlarm","params":{"sid":"' + body_13.group(1) + '","uid":"' + uid_alarm + '","username":"user","unitnum":"1","devicetype":"SS"},"id":"298"}'
			req = urllib2.Request(url_x, body_AcknowledgeAlarm, headers)
			
			#get response
			response = urllib2.urlopen(req)     
			the_response = response.read()
			
			#Reset Alarm
			body_ResetAlarm = 'm={"jsonrpc":"2.0","method":"ResetAlarm","params":{"sid":"' + body_13.group(1) + '","uid":"' + uid_alarm + '","username":"user","unitnum":"1","devicetype":"SS"},"id":"297"}'
			req = urllib2.Request(url_x, body_ResetAlarm, headers)
			
			#get response
			response = urllib2.urlopen(req)      
			the_response = response.read()
			#//time.sleep(3)
			
		print "------"
		print j
		print "------"    

	print '-------EOF------'

if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	#if len(sys.argv) > 1:
		ip = "10.161.93.24"  # sys.argv[1]
		print ip
		addconfigure(ip)

