#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import md5
import time
from datetime import datetime, tzinfo

#G4 get logs test by cgi method "GetLogData" by Dancy Yue on 12/22/16

print '\n'

def addconfigure(ip):

	#####################################################
	url_1 = 'http://'
	url_2 = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1438312968239'
	url = url_1 + ip + url_2
	url_x = url_1 + ip + '/cgi-bin/mgw.cgi'
					
	Referer = 'http://' + ip + '/'
	Origin = 'http://' + ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'
	body_sid = 'json=%7B%22lastMessageHash%22%3Anull%2C%22userName%22%3A%22user%22%2C%22passwordHash%22%3A%221a1dc91c907325c69271ddf0c944bc72%22%2C%22objType%22%3A%22LoginRequest%22%2C%22messageHash%22%3A%2245734895739857964%22%2C%22salt%22%3A%22abcdefghijk%22%7D'

	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}
	   
	req = urllib2.Request(url)
	response = urllib2.urlopen(req)    
	the_page = response.read()

	body_13 = re.search(r"sid\"\:\"(.*)\"\}\,\"i", the_page)


	for i in range(0, 1):
						  
			body_GetLogData= 'm={"jsonrpc":"2.0","method":"GetLogData","params":{"sid":"' + body_13.group(1) + '","lgiid":"1311200659","ptr":"4098616146:AllLightsOn"},"id":"79"}'
					
			#send the request
			req = urllib2.Request(url_x, body_GetLogData, headers)
							
			#get response
			response = urllib2.urlopen(req)  
			the_response = response.read()					
			
			#print the_response		                		
			print "GetLogs successfully"		
			
	print '-------EOF------'

	os.system('pause')

if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	if len(sys.argv) > 1:
		ip = sys.argv[1]
		print ip
		addconfigure(ip)
