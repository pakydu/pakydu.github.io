#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import time
from datetime import datetime, tzinfo


#add/delete app by RCI by Heaton Liang 2016/03/14
#add "modify app" and edit the original scripts by Dancy Yue on 12/07/2016
print '\n'
print "---------------------------------"
print "Tool starts at:"



def addconfigure(ip):

	starttime = datetime.now()
	print starttime

	waitTime = 3

	#define the number
	m = 0
	n = 0
	p = 0
	q = 0


	#####################################################
	url_1 = 'http://'
	url_2 = '/cgi-bin/rci.cgi'
	url = url_1 + ip + url_2
	Referer = url_1 + ip + '/g4testool/settings.html'
	Origin = url_1 + ip
	Host = ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'
	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Host' : Host}
	values = 'json={"lastMessageHash":null,"userName":"user","passwordHash":"1a1dc91c907325c69271ddf0c944bc72","objType":"LoginRequest","version":"2","messageHash":"","salt":"abcdefghijk"}'

	#login and get sid
	req = urllib2.Request(url, values, headers)
	response = urllib2.urlopen(req)
	the_page = response.read()
	body_13 = re.search(r"sid\"\:\"(.*)\"\,\"messageHash", the_page)


	#write the run log
	#f_result = open("G4_add_delete_by_cgi_log.txt",'w+')

	while True:
			#add App with a random app name
			print "add application start..."
			app_name = ''.join(random.sample(string.ascii_letters + string.digits,10))        
					
			body_add_app = 'json={"applicationTypeName":"XR75CX","instanceCount":"1","name":"' + app_name + '","objType":"AddApplicationRequest","version":"2","sid":"' + body_13.group(1) + '"}'		
			
			req = urllib2.Request(url, body_add_app, headers)
			try:
				response = urllib2.urlopen(req)       
				the_response = response.read()

				app_hash = re.search(r"applicationHash\"\:\"(.*)\"\,\"applicationName", the_response)
				result_get = re.search(r"ERROR*", the_response)

				if (result_get):
					print "add app fail"           
					p += 1
				else:
					print "add app successfully"
					q += 1

				print "add successful number is:", q
				print "add fail number is:", p

				if(app_hash):
					print "Get the new app hash"
				else:
					print "---!!!ERROR---Can't get app hash, script will exit!!!---"
					print "---------------------------------"
					print "Tool stops at:"

					stoptime = datetime.now()
					print stoptime
					print "---------------------------------"
					
					#sys.exit(0)
					time.sleep(10)
			finally:
				print "---------------------------------"


			#modify app values
			print "modify application setpoint values start..."
			body_modify = 'json={"lastMessageHash":null,"locator":{"applicationHash":"' + app_hash.group(1) + '","applicationName":"' + app_name + '","applicationTypeHash":"306","applicationTypeName":"XR75CX","deviceId":"1","objType":"Locator","pointHash":null,"pointName":null},"modifications":[{"id":"SEt","objType":"ApplicationConfigurationModification","value":"12"}],"objType":"ModifyApplicationConfigurationRequest","version":"2","sid":"' + body_13.group(1) + '"}'
		  
			req = urllib2.Request(url, body_modify, headers)
			try:
				response = urllib2.urlopen(req)        
				the_response_modify = response.read()
				time.sleep(1)
				print "modify application setpoint values successfully"
			finally:
				print "---------------------------------"


			#delete this application
			print "delete application start..."
			body_delete = 'json={"locator":{"applicationHash":"' + app_hash.group(1) + '","objType":"Locator"},"objType":"DeleteApplicationRequest","version":"2","sid":"' + body_13.group(1) + '"}'
				   
			req = urllib2.Request(url, body_delete, headers)
			try:
				response = urllib2.urlopen(req)
				the_response_delete = response.read()

				result_get = re.search(r"ERROR*", the_response_delete)

				if (result_get):
					print "delete app fail"
					m += 1
				else:
					print "delete app successfully"
					n += 1

				print "Delete successful number is:", n

				print "Delete fail number is:", m

				time.sleep(1)
                                
			finally:
				print "---------------------------------"

	print '-------EOF------'

	os.system('pause')
	
if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	#if len(sys.argv) > 1:
		ip = "10.161.93.24"  #sys.argv[1]
		print ip
		addconfigure(ip)
