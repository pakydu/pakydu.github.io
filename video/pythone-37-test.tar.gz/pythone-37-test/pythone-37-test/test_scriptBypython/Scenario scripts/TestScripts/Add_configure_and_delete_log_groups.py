#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import string
import random
import time



print '\n'

def addconfigure(ip):
	#��ȡSID

	url_1 = 'http://'
	url_2 = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1438312968239'
	url = url_1 + ip + url_2
	url_x = url_1 + ip + '/cgi-bin/mgw.cgi'              
	Referer = 'http://' + ip + '/'
	Origin = 'http://' + ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'

	headers = {'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}
	   
	req = urllib2.Request(url)
	response = urllib2.urlopen(req)    
	the_page = response.read()
	body_13 = re.search(r"sid\"\:\"(.*)\"\}\,\"i", the_page)

	for j in range(0, 655350):

		#��ʼ��list
		iid_list = []

		#����10��Log group���޸����ã�Ȼ���һ��ʱ��󣬽����������ã�Ȼ��ɾ����log group
		for i in range(0, 10):

			body_add_app = 'm={"jsonrpc":"2.0","method":"AddApp","params":{"sid":"' + body_13.group(1) + '","apptype":"Log Group"},"id":"41"}'
			req = urllib2.Request(url_x, body_add_app, headers)
			#get response
			response = urllib2.urlopen(req)
			the_response = response.read()

			#��Ҫ��ȡϵͳ�����IID
			iid_get = re.search(r"iid\"\:\"(.*)\"\}\,\"id", the_response)

			#��������log group iidд��list���ں�������
			iid_list.append(iid_get.group(1))

			#����ͬһ��log group�������Σ�Ȼ��׼��ɾ��
			log_name = ''.join(random.sample(string.ascii_letters + string.digits,10))
			print log_name
			body_set_app = 'm={"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"' + body_13.group(1) + '","points":[{"ptr":"'+ iid_get.group(1) +':AppName","val":"' + log_name + '"},{"ptr":"'+ iid_get.group(1) +':LogInterval","val":"120"},{"ptr":"'+ iid_get.group(1) +':LogDuration","val":"13.00"},{"ptr":"'+ iid_get.group(1) +':ArchiveEnable","val":"1"},{"ptr":"'+ iid_get.group(1) +':ArchiveNoticePercent","val":"79"},{"ptr":"'+ iid_get.group(1) +':ArcPerAlmDly","val":"62"},{"ptr":"'+ iid_get.group(1) +':LGRALMARCPER~Archive Percentage Full~Archive Percentage Full","val":"Non-Critical"},{"ptr":"'+ iid_get.group(1) +':LGRALMARCPER~Archive Percentage Full~Repeat Rate","val":"60"}]},"id":"166"}'
			req = urllib2.Request(url_x, body_set_app, headers)
			#get response
			response = urllib2.urlopen(req)
			the_response = response.read()
			#print the_response 

			#����ͬһ��log group�������Σ�Ȼ��׼��ɾ��
			log_name = ''.join(random.sample(string.ascii_letters + string.digits,10))
			print log_name
			body_set_app = 'm={"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"' + body_13.group(1) + '","points":[{"ptr":"'+ iid_get.group(1) +':AppName","val":"' + log_name + '"},{"ptr":"'+ iid_get.group(1) +':LogInterval","val":"120"},{"ptr":"'+ iid_get.group(1) +':LogDuration","val":"13.00"},{"ptr":"'+ iid_get.group(1) +':ArchiveEnable","val":"1"},{"ptr":"'+ iid_get.group(1) +':ArchiveNoticePercent","val":"79"},{"ptr":"'+ iid_get.group(1) +':ArcPerAlmDly","val":"62"},{"ptr":"'+ iid_get.group(1) +':LGRALMARCPER~Archive Percentage Full~Archive Percentage Full","val":"Non-Critical"},{"ptr":"'+ iid_get.group(1) +':LGRALMARCPER~Archive Percentage Full~Repeat Rate","val":"60"}]},"id":"166"}'
			req = urllib2.Request(url_x, body_set_app, headers)
			#get response
			response = urllib2.urlopen(req)
			the_response = response.read()
			#print the_response
			print "Log Group",i
			//time.sleep(1)


		body_delete_app = 'm={"jsonrpc":"2.0","method":"RemoveApps","params":{"sid":"' + body_13.group(1) + '","iids":' + str(iid_list) + '},"id":"41"}'
						  
		#print body_delete_app

		req = urllib2.Request(url_x, body_delete_app, headers)

		response = urllib2.urlopen(req)
		
		the_response = response.read()

		#print the_response

		print "------delete all log group------"

		print j

		print "------run cycle------"
			

	print 'the end'

if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	if len(sys.argv) > 1:
		ip = sys.argv[1]
		print ip
		addconfigure(ip)