#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import time
import string
import random
#import time


#log group����Ҫ�������в��� by Heaton Liang 2015/12/08

print '\n'


def addconfigure(ip):

	#��ȡSID
	url_1 = 'http://'
	url_2 = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1438312968239'
	url = url_1 + ip + url_2
	url_x = url_1 + ip + '/cgi-bin/mgw.cgi'                
	Referer = 'http://' + ip + '/'
	Origin = 'http://' + ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'

	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}
	   
	req = urllib2.Request(url)
	response = urllib2.urlopen(req)    
	the_page = response.read()

	body_13 = re.search(r"sid\"\:\"(.*)\"\}\,\"i", the_page)

	#ͨ��GetSystemInventory�õ�Global Data��iid
	Body_GetSystemInventory = 'm={"jsonrpc":"2.0","method":"GetSystemInventory","params":{"sid":"' + body_13.group(1) + '"},"id":"166"}'
	req = urllib2.Request(url_x, Body_GetSystemInventory, headers)
	response = urllib2.urlopen(req)
	the_response = response.read()
	print the_response

	#json ways
	globaldata_iid = 0
	jreq = json.loads(the_response)
	print jreq
	for ap in jreq['result']['aps']:
			if ap['apptype'] == 'Global Data':
					globaldata_iid = ap['iid']
	print globaldata_iid

	#print the_response
	#app_type = re.findall(r"apptype\"\:\"(.*?)\"\,\"", the_response)
	#app_iid = re.findall(r"iid\"\:\"(\d+)\"\,\"name", the_response)
	#print app_type
	#print app_iid
	#for j in range(0, len(app_iid)):
	#        if (app_type[j] == 'Global Data'):
	#                globaldata_iid = app_iid[j]
	#print globaldata_iid

	#����һ��log group
	body_add_app = 'm={"jsonrpc":"2.0","method":"AddApp","params":{"sid":"' + body_13.group(1) + '","apptype":"Log Group"},"id":"41"}'
	req = urllib2.Request(url_x, body_add_app, headers)
	response = urllib2.urlopen(req)
	the_response = response.read()
	print the_response
	#��Ҫ��ȡϵͳ�����IID
	iid_get = re.search(r"iid\"\:\"(.*)\"\}\,\"id", the_response)
	print iid_get.group(1)

	for j in range(0, 655350):

		#�����ӵ�Log Group��ĳЩproperties����set����
		log_name = ''.join(random.sample(string.ascii_letters + string.digits,10))
		body_set_app = 'm={"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"' + body_13.group(1) + '","points":[{"ptr":"'+ iid_get.group(1) +':AppName","val":"' + log_name + '"},{"ptr":"'+ iid_get.group(1) +':LogInterval","val":"120"},{"ptr":"'+ iid_get.group(1) +':LogDuration","val":"13.00"},{"ptr":"'+ iid_get.group(1) +':ArchiveEnable","val":"1"},{"ptr":"'+ iid_get.group(1) +':ArchiveNoticePercent","val":"79"},{"ptr":"'+ iid_get.group(1) +':ArcPerAlmDly","val":"62"},{"ptr":"'+ iid_get.group(1) +':LGRALMARCPER~Archive Percentage Full~Archive Percentage Full","val":"Non-Critical"},{"ptr":"'+ iid_get.group(1) +':LGRALMARCPER~Archive Percentage Full~Repeat Rate","val":"60"}]},"id":"166"}'
		req = urllib2.Request(url_x, body_set_app, headers)
		#get response
		response = urllib2.urlopen(req)
		the_response = response.read()
		print the_response
			
		#ע��global data��103��properties.
		body_register_ponit = 'm={"jsonrpc":"2.0","method":"RegisterLogPoint","params":{"sid":"' + body_13.group(1) + '","points":[{"ptr":"'+ globaldata_iid +':OutdoorTemp","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutdoorHumid","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':IndoorHumidIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LightLevelIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrPhaseIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacPhaseIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrEmerIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacEmerIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':AllLightsIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CurtailmentIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SmmrWntrIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OatOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutdoorHumOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':IndoorHumOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LightLevelOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CurtailmentOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':AllLightsOn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacEmerOv","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrEmerOv","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacPhaseLoss","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrPhaseLoss","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SummerWinter","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CoolingDegreeDay","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HeatingDegreeDay","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':EnthalpyDegreeDay","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutAirStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutRHStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':InRHStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LightLevelStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CurtailStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':AllLightsStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HVACShutdownStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrShutdownStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HVACPhaseLossStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrPhaseLossStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SummerWinterStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HolidayStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog1Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog2Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog3Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog4Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog5Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog6Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog7Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog8Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital1Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital2Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital3Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital4Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital5Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital6Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital7Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital8Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':Sundown","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SundownTSCOS","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SundownTUCOS","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SunriseTime","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SunsetTime","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':ActiveLatitude","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':ActiveLongitude","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamKbFree","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamKbUsed","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamBuffers","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamCached","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamFreePct","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamFreeLow","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CpuUsageCurrent","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CpuUsageMax","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LoadAvg1Min","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LoadAvg5Min","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LoadAvg15Min","lgiid":"' + iid_get.group(1) + '"}]},"id":"241"}'
		req = urllib2.Request(url_x, body_register_ponit, headers)
		response = urllib2.urlopen(req)
		the_response = response.read()
		print the_response

		#��ѯע��ɹ���point
		body_get_register_ponit = 'm={"jsonrpc":"2.0","method":"GetPointsForLogGroup","params":{"sid":"' + body_13.group(1) + '","lgiid":"' + iid_get.group(1) + '"},"id":"161"}'
		req = urllib2.Request(url_x, body_get_register_ponit, headers)
		#get response
		response = urllib2.urlopen(req)
		the_response = response.read()
		#print the_response

		#�ȴ�5��
		time.sleep(1)

		#��ע��global data��103��properties.
		body_unregister_ponit = 'm={"jsonrpc":"2.0","method":"UnregisterLogPoint","params":{"sid":"' + body_13.group(1) + '","points":[{"ptr":"'+ globaldata_iid +':OutdoorTemp","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutdoorHumid","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':IndoorHumidIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LightLevelIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrPhaseIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacPhaseIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrEmerIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacEmerIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':AllLightsIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CurtailmentIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SmmrWntrIn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogIn8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalIn8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OatOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutdoorHumOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':IndoorHumOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LightLevelOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CurtailmentOut","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':AllLightsOn","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacEmerOv","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrEmerOv","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HvacPhaseLoss","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrPhaseLoss","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SummerWinter","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CoolingDegreeDay","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HeatingDegreeDay","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':EnthalpyDegreeDay","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalogOut8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut1","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut2","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut3","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut4","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut5","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut6","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut7","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigitalOut8","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutAirStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':OutRHStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':InRHStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LightLevelStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CurtailStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':AllLightsStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HVACShutdownStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrShutdownStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HVACPhaseLossStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':RefrPhaseLossStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SummerWinterStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':HolidayStatus","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog1Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog2Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog3Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog4Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog5Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog6Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog7Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareAnalog8Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital1Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital2Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital3Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital4Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital5Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital6Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital7Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SpareDigital8Status","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':Sundown","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SundownTSCOS","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SundownTUCOS","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SunriseTime","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SunsetTime","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':ActiveLatitude","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':ActiveLongitude","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamKbFree","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamKbUsed","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamBuffers","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamCached","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamFreePct","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':SysRamFreeLow","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CpuUsageCurrent","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':CpuUsageMax","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LoadAvg1Min","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LoadAvg5Min","lgiid":"' + iid_get.group(1) + '"},{"ptr":"'+ globaldata_iid +':LoadAvg15Min","lgiid":"' + iid_get.group(1) + '"}]},"id":"241"}'
		req = urllib2.Request(url_x, body_unregister_ponit, headers)
		#get response
		response = urllib2.urlopen(req)
		the_response = response.read()
		print the_response

		#�ȴ�5��
		time.sleep(1)
		
		print j

		print "------run cycle------"
	print 'the end'

if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	if len(sys.argv) > 1:
		ip = sys.argv[1]
		print ip
		addconfigure(ip)