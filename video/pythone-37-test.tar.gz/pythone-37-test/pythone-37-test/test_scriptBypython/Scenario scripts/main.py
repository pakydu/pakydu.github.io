#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk

import subprocess
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import time
from datetime import datetime, tzinfo

#Created by Dancy Yue 12/16

def readIP():
	fd = open("G4IP","r")
	ip = fd.readline().strip('\n') 
	fd.close();
	return ip

def runAll(rootDir, ip):  
	#return the list of file or file folder in rootDir path
    for list in os.listdir(rootDir):       
        path = os.path.join(rootDir, list)
        if os.path.isdir(path):
            continue
        command = 'python ' + path + ' ' + ip
        print command
        subprocess.Popen(command)

#main function			
if __name__ == '__main__':
	ip = readIP()
	runAll("TestScripts", ip)
