1. Make sure your PC install Python;
2. Restore with 2.00B45 - HD Acworth_safe.SSBackup in SS;
(Note: If this setpoint file is not used, Lighting and XR75CX won't be found; Service Logs will print some error logs;)
3. Check the points "Free System RAM (kb)" and "Current CPU Usage" be logged in Global Data;
4. Open putty, using top to check Memory and CPU usage;
5. Modify G4IP;
6. Run main.py.
