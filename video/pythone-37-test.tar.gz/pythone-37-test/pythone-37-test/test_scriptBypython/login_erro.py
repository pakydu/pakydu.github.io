#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import md5
import time
from datetime import datetime, tzinfo



#add_delete_alarm_transmissions by cgi methods "AddAlarmPropagationRuleset","EditAlarm","DeleteAlarmPropagationRuleset" by Dancy Yue on 12/14/16
print '\n'
print "---------------------------------"

def addconfigure(ip):

	#define the number
	p = 0
	q = 0
	r = 0
	s = 0
	m = 0
	n = 0
	
	#####################################################
	url_1 = 'http://'
	url_2 = '/cgi-bin/rci.cgi'
	url_3 = '/cgi-bin/mgw.cgi'
	url_4 = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1438312968239'
	url = url_1 + ip + url_2
	Referer = url_1 + ip + '/g4testool/settings.html'
	Origin = url_1 + ip
	Host = ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'
	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Host' : Host}
	#values = 'json={"lastMessageHash":null,"userName":"user","passwordHash":"1a1dc91c907325c69271ddf0c944bc72","objType":"LoginRequest","version":"2","messageHash":"","salt":"abcdefghijk"}'
	values = ''

	#login and get sid
	req = urllib2.Request(url, values, headers)
	response = urllib2.urlopen(req)
	the_page = response.read()
	print the_page
	#decodejson = json.loads(the_page)
	#print type(decodejson)
	#print decodejson
	#print decodejson['result']['sid']
	#return decodejson['result']['sid']
	#body_13 = re.search(r"sid\"\:\"(.*)\"\,\"messageHash", the_page)
	#print body_13
	print '-------EOF------'


if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	#if len(sys.argv) > 1:
		ip = "10.161.93.161"  # sys.argv[1]
		print ip
		addconfigure(ip)
