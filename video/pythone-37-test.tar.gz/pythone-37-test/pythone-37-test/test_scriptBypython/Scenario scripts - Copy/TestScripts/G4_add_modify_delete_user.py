#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import time
from datetime import datetime, tzinfo


#G4 cgi api test by RCI by Heaton Liang 2016/03/21
#add "modify user" and "delete user" and edit the original scripts by Dancy Yue on 12/08/16

print '\n'

def addconfigure(ip):

	#####################################################
	url_1 = 'http://'
	url_2 = '/cgi-bin/rci.cgi'
	url = url_1 + ip + url_2
	Referer = url_1 + ip + '/g4testool/settings.html'
	Origin = url_1 + ip
	Host = ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'
	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Host' : Host}
	values = 'json={"lastMessageHash":null,"userName":"user","passwordHash":"1a1dc91c907325c69271ddf0c944bc72","objType":"LoginRequest","version":"2","messageHash":"","salt":"abcdefghijk"}'

	#login and get sid
	req = urllib2.Request(url, values, headers)
	response = urllib2.urlopen(req)
	the_page = response.read()
	body_13 = re.search(r"sid\"\:\"(.*)\"\,\"messageHash", the_page)


	for i in range(0, 65536):

			#Add new user
			body_request = 'json={"objType":"ModifyUsersInfoRequest","version":"2","sid":"927b6488-3d16-475c-84fc-5dc82eeb548c","userInfos":[{"action":"createOrUpdate","actualName":"Default User","cellPhone":"' + str(random.randint(4000000000,4009999999)) + '","description":"The first default user1","email":"test@emerson.com","isEnergyManager":true,"isMonitoringStaff":true,"isNonTechnicalEndUser":true,"isSystemAdmin":true,"isTechnician":true,"objType":"UserModifyElement","officePhone":"' + str(random.randint(4000000000,4009999999)) + '","password":"1a1dc91c907325c69271ddf0c944bc72","sms":"' + str(random.randint(4000000000,4009999999)) + '","userName":"test"}]}'
			req = urllib2.Request(url, body_request, headers)
			response = urllib2.urlopen(req)

			#Modify this user
			#Modify the added user's actual name and email
			body_request = 'json={"objType":"ModifyUsersInfoRequest","version":"2","sid":"927b6488-3d16-475c-84fc-5dc82eeb548c","userInfos":[{"action":"createOrUpdate","actualName":"SS","cellPhone":"' + str(random.randint(4000000000,4009999999)) + '","description":"The first default user1","email":"SS@emerson.com","isEnergyManager":true,"isMonitoringStaff":true,"isNonTechnicalEndUser":true,"isSystemAdmin":true,"isTechnician":true,"objType":"UserModifyElement","officePhone":"' + str(random.randint(4000000000,4009999999)) + '","password":"1a1dc91c907325c69271ddf0c944bc72","sms":"' + str(random.randint(4000000000,4009999999)) + '","userName":"test"}]}'
			req = urllib2.Request(url, body_request, headers)
			response = urllib2.urlopen(req)
			
			#Delete this modified user
			body_request = 'json={"objType":"ModifyUsersInfoRequest","version":"2","sid":"927b6488-3d16-475c-84fc-5dc82eeb548c","userInfos":[{"action":"delete","actualName":"SS","cellPhone":"' + str(random.randint(4000000000,4009999999)) + '","description":"The first default user1","email":"SS@emerson.com","isEnergyManager":true,"isMonitoringStaff":true,"isNonTechnicalEndUser":true,"isSystemAdmin":true,"isTechnician":true,"objType":"UserModifyElement","officePhone":"' + str(random.randint(4000000000,4009999999)) + '","password":"1a1dc91c907325c69271ddf0c944bc72","sms":"' + str(random.randint(4000000000,4009999999)) + '","userName":"test"}]}'
			req = urllib2.Request(url, body_request, headers)
			response = urllib2.urlopen(req)
			
			print 'The run times is:'
			print i+1
			
			print '---------------------------'

	print '-------EOF------'

	os.system('pause')

if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	if len(sys.argv) > 1:
		ip = sys.argv[1]
		print ip
		addconfigure(ip)
