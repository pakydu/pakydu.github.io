#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import md5
import time
from datetime import datetime, tzinfo



#add_delete_alarm_transmissions by cgi methods "AddAlarmPropagationRuleset","EditAlarm","DeleteAlarmPropagationRuleset" by Dancy Yue on 12/14/16
print '\n'
print "---------------------------------"

def addconfigure(ip):

	#define the number
	p = 0
	q = 0
	r = 0
	s = 0
	m = 0
	n = 0
	
	#####################################################
	url_1 = 'http://'
	url_2 = '/cgi-bin/rci.cgi'
	url_3 = '/cgi-bin/mgw.cgi'
	url_4 = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1438312968239'
	url = url_1 + ip + url_2
	Referer = url_1 + ip + '/g4testool/settings.html'
	Origin = url_1 + ip
	Host = ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'
	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Host' : Host}
	values = 'json={"lastMessageHash":null,"userName":"user","passwordHash":"1a1dc91c907325c69271ddf0c944bc72","objType":"LoginRequest","version":"2","messageHash":"","salt":"abcdefghijk"}'

	#login and get sid
	req = urllib2.Request(url, values, headers)
	response = urllib2.urlopen(req)
	the_page = response.read()
	body_13 = re.search(r"sid\"\:\"(.*)\"\,\"messageHash", the_page)


	#get applications request
	body_2 = 'json={"lastMessageHash":"null","objType":"GetApplicationsRequest","version":"2","sid":"927b6488-3d16-475c-84fc-5dc82eeb548c"}'
	req = urllib2.Request(url, body_2, headers)
	response = urllib2.urlopen(req)
	the_page = response.read()

	#"applicationHash":"3470707716","applicationName":"System Settings", get "System Settings" Hash
	body_23 = re.search(r"applicationHash\"\:\"(\d+)\"\,\"applicationName\"\:\"System\sSettings", the_page)
	url = url_1 + ip + url_4
	req = urllib2.Request(url)
	response = urllib2.urlopen(req)    
	the_page = response.read()

	#get sid
	sid_mgw = re.search(r"sid\"\:\"(.*)\"\}\,\"i", the_page)
	print sid_mgw

	#Set SMTP Server: Enable SMTP and Add SMTP Server IP
	body_modify = 'm={"jsonrpc":"2.0","method":"SetPointValues","params":{"sid":"927b6488-3d16-475c-84fc-5dc82eeb548c","points":[{"ptr":"' + body_23.group(1) + ':SMTPEnabled","val":"1"},{"ptr":"' + body_23.group(1) + ':SmtpServer","val":"10.212.197.50"}]},"id":"142"}'
	print body_modify
	   
	url = url_1 + ip + url_3
	req = urllib2.Request(url, body_modify, headers)
	response = urllib2.urlopen(req)       
	the_response = response.read()

	print "---------SMTP Configure sucessfully!-----------"


	#目前的规格是20个alarm transmission配置
	for i in range(0, 65536):

		#输出随机name
		username = ''.join(random.sample(string.ascii_letters + string.digits, 18))
		print username
		
		#Add Alarm Notice
		body_add_AlarmNotice = 'm={"jsonrpc":"2.0","method":"AddAlarmPropagationRuleset","params":{"sid":"927b6488-3d16-475c-84fc-5dc82eeb548c","alarmprop":{"appoutput":"","relay1":"Not enabled","relay2":"Not enabled","relay3":"Not enabled","relay4":"Not enabled","name":"' + username + '","catfilter":["Any"],"resfilter":["Any"],"attrfilter":["Any"],"schedule":"","recipients":[{"username":"user","email":"true","sms":"true"}]}},"id":"169"}'
			
		#send the request
		url = url_1 + ip + '/cgi-bin/mgw.cgi'
		req = urllib2.Request(url, body_add_AlarmNotice, headers)

		#get response
		response = urllib2.urlopen(req)  
		the_response = response.read()

		print "---------------------------------"
		
		#{"jsonrpc":"2.0","result":{"status":"ok"},"id":"86"}
		result_get = re.search(r"error*", the_response)

		#get status
		if (result_get):
			print "add alarm transmission fail"           
			p += 1            
		else:                
			print "add alarm transmission successfully"
			q += 1
			
		print "add fail number is:"
		print p
		print "add sucessful number is:"
		print q

		print "--------------Finish Add Alarm Notice -------------------"
		

		#Edit Alarm Notice
		body_edit_AlarmNotice = 'm={"jsonrpc":"2.0","method":"EditAlarmPropagationRuleset","params":{"sid":"927b6488-3d16-475c-84fc-5dc82eeb548c","alarmprop":{"appoutput":"","relay1":"Active until acknowledged","relay2":"Active until muted","relay3":"Timed one-shot pulse - 1","relay4":"Active until acknowledged","name":"' + username + '","catfilter":["Any"],"resfilter":["Any"],"attrfilter":["Any"],"schedule":"","recipients":[{"username":"user","email":"true","sms":"true"}]}},"id":"169"}'   
			
		#send the request
		url = url_1 + ip + '/cgi-bin/mgw.cgi'
		req = urllib2.Request(url, body_edit_AlarmNotice, headers)

		#get response
		response = urllib2.urlopen(req)  
		the_response = response.read()

		print "---------------------------------"
		
		result_get = re.search(r"error*", the_response)

		#get status
		if (result_get):
			print "edit alarm transmission fail"           
			r += 1            
		else:                
			print "edit alarm transmission successfully"
			s += 1
			
		print "edit fail number is:"
		print r
		print "edit successfully number is:"
		print s

		print "--------------Finish Edit Alarm Notice -------------------"
		

		#Delete Alarm Notice
		body_delete_user = 'm={"jsonrpc":"2.0","method":"DeleteAlarmPropagationRuleset","params":{"sid":"927b6488-3d16-475c-84fc-5dc82eeb548c","name":"' + username + '"},"id":"30"}'
		print body_delete_user  
		
		#send the request
		url = url_1 + ip + '/cgi-bin/mgw.cgi'
		req = urllib2.Request(url, body_delete_user, headers)

		#get response
		response = urllib2.urlopen(req)  
		the_response = response.read()

		print "---------------------------------"
		
		result_get = re.search(r"error*", the_response)

		#get status
		if (result_get):
			print "delete alarm transmission fail"      
			m += 1         
		else:                
			print "delete alarm transmission successfully"
			n += 1

		print "delete fail number is:"
		print m
		print "delete successful number is:"
		print n

		print "--------------Finish Delete Alarm Notice -------------------"
		
	print '-------EOF------'


if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	if len(sys.argv) > 1:
		ip = sys.argv[1]
		print ip
		addconfigure(ip)