#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding = gbk
import urllib    
import urllib2
import json
import re
import sys
import httplib
import timeit
import os
import random
import string
import time
from datetime import datetime, tzinfo

#Original scripts by Heaton Liang 2015/12/08
#override light by cgi method "OverridePoint" edited by Dancy Yue on 12/08/16
print '\n'
print "---------------------------------"

def addconfigure(ip):

	#####################################################
	url_1 = 'http://'
	url_2 = '/cgi-bin/mgw.cgi?m={"jsonrpc":"2.0","method":"GetSessionID","id":"1"}&_=1438312968239'
	url = url_1 + ip + url_2
	url_x = url_1 + ip + '/cgi-bin/mgw.cgi'
					
	Referer = 'http://' + ip + '/'
	Origin = 'http://' + ip
	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
	Proxy = 'keep-alive'
	Language = 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4'
	Encoding = 'gzip, deflate'
	XWith = 'XMLHttpRequest'
	body_sid = 'json=%7B%22lastMessageHash%22%3Anull%2C%22userName%22%3A%22user%22%2C%22passwordHash%22%3A%223fad88420a85798e4e41157311047fc0%22%2C%22objType%22%3A%22LoginRequest%22%2C%22messageHash%22%3A%2245734895739857964%22%2C%22salt%22%3A%22abcdefghijk%22%7D'

	headers = { 'User-Agent' : user_agent, 'X-Requested-With' : XWith, 'Referer' : Referer, 'Accept-Language' : Language, 'Accept-Encoding' : Encoding, 'Origin' : Origin}
	   
	req = urllib2.Request(url)
	response = urllib2.urlopen(req)    
	the_page = response.read()

	body_13 = re.search(r"sid\"\:\"(.*)\"\}\,\"i", the_page)

	for j in range(0, 1):

		override_time = random.randrange(0,86400)
		print override_time

		body_override = 'm={"jsonrpc":"2.0","method":"OverridePoint","params":{"sid":"' + body_13.group(1) + '","ptr":"2639611595:LightsOutput","override":"true","overridetime":"' + str(override_time) + '","val":"1"},"id":"1834"}'
				
		#send the request
		req = urllib2.Request(url_x, body_override, headers)

		#get response
		response = urllib2.urlopen(req)  
		the_response = response.read()
		
		print the_response
		# override_time_1 = random.randrange(0,86400)
		# print override_time_1

		# body_override = 'm={"jsonrpc":"2.0","method":"OverridePoint","params":{"sid":"' + body_13.group(1) + '","ptr":"2639611595:LightsOutput","override":"true","overridetime":"' + str(override_time_1) + '","val":"1"},"id":"1834"}'
				
		# #send the request
		# req = urllib2.Request(url_x, body_override, headers)

		# #get response
		# response = urllib2.urlopen(req)    
		# the_response = response.read()
		# override_time_2 = random.randrange(0,86400)
		# print override_time_2

		# body_override = 'm={"jsonrpc":"2.0","method":"OverridePoint","params":{"sid":"' + body_13.group(1) + '","ptr":"2639611595:LightsOutput","override":"ture","overridetime":"' + str(override_time_2) + '","val":"0"},"id":"1834"}'          
		# #send the request
		# req = urllib2.Request(url_x, body_override, headers)
		
		# #get response
		# response = urllib2.urlopen(req)
		# the_response = response.read()
		# override_time_3 = random.randrange(0,86400)
		# print override_time_3
		
		# body_override = 'm={"jsonrpc":"2.0","method":"OverridePoint","params":{"sid":"' + body_13.group(1) + '","ptr":"2639611595:LightsOutput","override":"false","overridetime":"' + str(override_time_3) + '","val":"0"},"id":"1834"}'
				
		# #send the request
		# req = urllib2.Request(url_x, body_override, headers)

		# #get response
		# response = urllib2.urlopen(req)
		# the_response = response.read()

	print 'the end'

if __name__ == "__main__":
	#sys.argv return a list and inculde all parameters in CMD line
	if len(sys.argv) > 1:
		ip = sys.argv[1]
		print ip
		addconfigure(ip)
