#import platform from distutils.core
#import setup,Extension from distutils
#import sysconfig

# cfg_vars=sysconfig.get_config_vars()

# if 'OPT' in cfg_vars:
#     cfg_vars['OPT']=cfg_vars['OPT'].replace('-Wstrict-prototypes','')
#     mod_expy=Extension('libxx.expy', 
#                        sources=['libxx/expy.c',],
#                        libraries=['jpeg',], 
#                        include_dirs=['/opt/local/include',], 
#                        library_dirs=['/opt/local/lib',], 
#                        define_macros=[('MAJOR_VERSION','1'),('MINOR_VERSION','0')], ) #区分各种平台的编译 
    
#     if platform.system()=='Darwin':
#         os.environ['ARCHFLAGS']='-arch x86_64'
#         extmodlist=[mod_expy,]
#     elif platform.system()='Linux':
#         os.environ['ARCHFLAGS']='-arch i386 -arch x86_64'
#         extmodlist=[mod_expy,] 
#     else:
#         raise RuntimeError('Unknown system()=%s'%repr(platform.system()))
        
# setup(name='libxx', 
#       version='1.0', 
#       description='libxx-python', 
#       author='gashero', 
#       author_email='xxx@xxx.xxx', 
#       packages=['libxx',], 
#       ext_modules=extmodlist, 
#       url='http://example.com/', 
#       long_description='xxxxxx xxxxxx', )

tar = [1,2,3,4]
cnt = 0

for i in range(len(tar)):
    t1 = tar.copy()
    x = str(t1.pop(i))
    for j in range(len(tar)):
        #t2 = t1.copy()
        t2 = tar.copy()
        y = str(t2.pop(j))
        for k in range(len(t2)):
            print(x+y+str(t2[k]), end= ' ')
            cnt+=1
    print(' ')
print("resutl: {} ge".format(cnt))