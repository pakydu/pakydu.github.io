import requests
import json

print("test...")

BASE_URL="http://10.161.93.24"

def getSSid():
    URL=BASE_URL + "/cgi-bin/mgw.cgi"
    payload = {'m':'{"jsonrpc":"2.0","method":"GetSessionID","id":"1"}'}
    #print(payload)
    #payload = {'key1': 'value1', 'key2': ['value2', 'value3']}
    rsq = requests.get(URL, params=payload)
    print("income...")
    print()
    decodejson = json.loads(rsq.text) 
    print(decodejson["result"]["sid"])


def test_json():
    rsq = requests.get("http://httpbin.org/get")
    print(type(rsq.text))
    print(rsq.json())
    print(json.loads(rsq.text))
    print(type(rsq.json()))

#getSSid()
#test_json()

def test_addHeader():
    url = 'https://www.zhihu.com/'
    headers = {
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
    }
    response = requests.get(url,headers=headers)
    #print(response.text)
    print("rsq code:", response.status_code)
    print("rsq header:", response.headers)
    print("req url:", response.url)

#test_addHeader()

url_base = "http://httpbin.org"

def test_uploadfile():
    url =  '/'.join([url_base, 'post'])
    print(url)
    files = {"files":open("test.jpg", 'rb')}
    rsq = requests.post(url, files=files)
    print(rsq.text)


#test_uploadfile()

def test_cookie():
    response = requests.get('https://www.baidu.com')
    print(response.cookies)
    for key,value in response.cookies.items():
        print(key,'==',value)


#test_cookie()

def test_https():
    url = 'https://www.12306.cn'
    #rsp = requests.get(url, cert=('/path/server.crt', '/path/key'))
    rsp = requests.get(url, verify=False)
    print(rsp.status_code)
    print("history:",rsp.history)

test_https()