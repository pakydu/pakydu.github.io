import time
from selenium import webdriver

wd = webdriver.Chrome(r'd:\chromedriver.exe')

wd.get('http://f.python3.vip/webauto/test2.html')

element = wd.find_element_by_css_selector(
  '#s_radio input[checked=checked]')
print('当前选中的是: ' + element.get_attribute('value'))

# 点选 小雷老师
wd.find_element_by_css_selector(
  '#s_radio input[value="小雷老师"]').click()
time.sleep(50000)
#wd.quit()