# -*- coding:UTF-8 -*-
from bs4 import BeautifulSoup
import requests



if __name__ == '__main__':
    #《一念永恒》menu:
    target = 'http://www.biqukan.com/1_1094/'

    resq = requests.get(url=target )
    resq.encoding = 'gbk'
    html = resq.text
    bf = BeautifulSoup(html)

    #find the 章节目录链接
    menuLists = bf.find_all('div', class_='listmain')
    # for text in menuLists:
    #     print(text.html)
    #     print(text.text)
    #     print('---------------------------------------')
    # #print("===================================")
    #print(texts[0].text.replace('\xa0'*8,'\n\n'))
    aTag = BeautifulSoup(str(menuLists[0]))

    #find the a tag
    aArr = aTag.find_all('a')
    for item in aArr:
        print(item.string, target+item.get('href'))